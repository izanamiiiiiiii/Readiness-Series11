#import <UIKit/UIKit.h>
@interface ReadinessHostDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@end
@implementation ReadinessHostDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
 self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
 UIViewController *controller = [UIViewController new];
 controller.view.backgroundColor = UIColor.systemBackgroundColor;
 UILabel *label = [UILabel new]; label.numberOfLines = 0;
 label.text = @"Readiness · Experimental\n\nEsta app contiene la aplicación para Apple Watch.\n\nCompleta la instalación en WatchBridge y abre Readiness en el reloj.\n\nEste host no calcula puntuaciones ni lee datos de Salud.";
 label.textColor = UIColor.labelColor; label.translatesAutoresizingMaskIntoConstraints = NO;
 [controller.view addSubview:label];
 [NSLayoutConstraint activateConstraints:@[[label.leadingAnchor constraintEqualToAnchor:controller.view.safeAreaLayoutGuide.leadingAnchor constant:24], [label.trailingAnchor constraintEqualToAnchor:controller.view.safeAreaLayoutGuide.trailingAnchor constant:-24], [label.centerYAnchor constraintEqualToAnchor:controller.view.centerYAnchor]]];
 self.window.rootViewController = controller; [self.window makeKeyAndVisible]; return YES;
}
@end
int main(int argc, char **argv) { @autoreleasepool { return UIApplicationMain(argc, argv, nil, NSStringFromClass(ReadinessHostDelegate.class)); } }
