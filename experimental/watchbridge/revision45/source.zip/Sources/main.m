#import <UIKit/UIKit.h>
#import <HealthKit/HealthKit.h>

@interface ReadinessProfileController : UIViewController
@property(nonatomic,strong) HKHealthStore *health;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) UIButton *authorize;
@property(nonatomic,strong) UIButton *refresh;
@end
@implementation ReadinessProfileController
- (void)viewDidLoad {
 [super viewDidLoad];
 self.view.backgroundColor = UIColor.systemBackgroundColor;
 self.health = [HKHealthStore new];
 UILabel *title = [UILabel new]; title.text = @"Readiness"; title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleLargeTitle];
 self.status = [UILabel new]; self.status.numberOfLines = 0;
 self.status.text = @"Allow Readiness to read your age, height, and weight from Health. Then open Readiness on your Apple Watch and allow its Health permissions too.";
 self.authorize = [UIButton buttonWithType:UIButtonTypeSystem];
 [self.authorize setTitle:@"Allow access to Health" forState:UIControlStateNormal];
 [self.authorize addTarget:self action:@selector(authorizeHealth) forControlEvents:UIControlEventTouchUpInside];
 self.refresh = [UIButton buttonWithType:UIButtonTypeSystem];
 [self.refresh setTitle:@"Check profile again" forState:UIControlStateNormal];
 [self.refresh addTarget:self action:@selector(readProfile) forControlEvents:UIControlEventTouchUpInside];
 UILabel *note = [UILabel new]; note.numberOfLines = 0;
 note.text = @"No health data is written or uploaded. If a field is unavailable, check Readiness permissions in Health and the existing record. This iPhone companion checks your profile; the watch reads its own authorized data.";
 note.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote]; note.textColor = UIColor.secondaryLabelColor;
 UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[title,self.status,self.authorize,self.refresh,note]];
 stack.axis=UILayoutConstraintAxisVertical; stack.spacing=20; stack.translatesAutoresizingMaskIntoConstraints=NO;
 [self.view addSubview:stack];
 [NSLayoutConstraint activateConstraints:@[[stack.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor constant:24],[stack.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor constant:-24],[stack.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:32],[stack.bottomAnchor constraintLessThanOrEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-16]]];
 [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(readProfile) name:UIApplicationDidBecomeActiveNotification object:nil];
}
- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; }
- (NSSet<HKObjectType *> *)readTypes {
 return [NSSet setWithObjects:[HKObjectType characteristicTypeForIdentifier:HKCharacteristicTypeIdentifierDateOfBirth],[HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierHeight],[HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierBodyMass],nil];
}
- (void)authorizeHealth {
 if (![HKHealthStore isHealthDataAvailable]) { self.status.text=@"Health data is not available on this device."; return; }
 self.authorize.enabled=NO; self.status.text=@"Waiting for the Health permission sheet…";
 __weak typeof(self) weakSelf=self;
 [self.health requestAuthorizationToShareTypes:[NSSet set] readTypes:self.readTypes completion:^(BOOL completed,NSError *error) {
  dispatch_async(dispatch_get_main_queue(), ^{
   typeof(self) self=weakSelf; if (!self) return;
   self.authorize.enabled=YES;
   if (error || !completed) {
    self.status.text=[NSString stringWithFormat:@"Health access could not be requested (%@ %ld). The signed app needs the HealthKit capability. Use the corrected installer and regenerate both app profiles, then reinstall.",error.domain ?: @"HealthKit",(long)error.code];
   } else { [self readProfile]; }
  });
 }];
}
- (void)readProfile {
 if (![HKHealthStore isHealthDataAvailable]) return;
 self.refresh.enabled=NO;
 NSError *birthError=nil; NSDateComponents *birth=[self.health dateOfBirthComponentsWithError:&birthError];
 BOOL birthAvailable=birth.year>0 && birth.month>0 && birth.day>0;
 NSMutableDictionary<NSString *,NSNumber *> *found=[NSMutableDictionary dictionaryWithObject:@(birthAvailable) forKey:@"Age"];
 dispatch_group_t group=dispatch_group_create();
 for (NSString *identifier in @[HKQuantityTypeIdentifierHeight,HKQuantityTypeIdentifierBodyMass]) {
  dispatch_group_enter(group);
  HKQuantityType *type=[HKObjectType quantityTypeForIdentifier:identifier];
  HKSampleQuery *query=[[HKSampleQuery alloc] initWithSampleType:type predicate:nil limit:1 sortDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:HKSampleSortIdentifierEndDate ascending:NO]] resultsHandler:^(HKSampleQuery *query,NSArray<HKSample *> *samples,NSError *error) {
   NSString *key=[identifier isEqualToString:HKQuantityTypeIdentifierHeight] ? @"Height" : @"Weight";
   @synchronized(found) { found[key]=@(!error && samples.count>0); }
   dispatch_group_leave(group);
  }];
  [self.health executeQuery:query];
 }
 __weak typeof(self) weakSelf=self;
 dispatch_group_notify(group,dispatch_get_main_queue(), ^{
  typeof(self) self=weakSelf; if (!self) return;
  self.refresh.enabled=YES;
  NSMutableArray *lines=[NSMutableArray new]; BOOL complete=YES;
  for (NSString *key in @[@"Age",@"Height",@"Weight"]) { BOOL available=found[key].boolValue; complete &= available; [lines addObject:[NSString stringWithFormat:@"%@: %@",key,available?@"available":@"not available to Readiness"]]; }
  self.status.text=[[lines componentsJoinedByString:@"\n"] stringByAppendingString:complete ? @"\n\nProfile readable on iPhone. Open Readiness on your Watch and allow its Health access. If the Watch still shows setup, close and reopen its app after granting permission." : @"\n\nAn unavailable field can mean missing data or restricted read access; HealthKit does not reveal which. Allow the three profile fields in Health. You do not need to re-enter values that already exist."];
 });
}
@end

@interface ReadinessSceneDelegate : UIResponder <UIWindowSceneDelegate>
@property(nonatomic,strong) UIWindow *window;
@end
@implementation ReadinessSceneDelegate
- (void)scene:(UIScene *)scene willConnectToSession:(UISceneSession *)session options:(UISceneConnectionOptions *)options {
 if (![scene isKindOfClass:UIWindowScene.class]) return;
 self.window=[[UIWindow alloc] initWithWindowScene:(UIWindowScene *)scene];
 self.window.rootViewController=[ReadinessProfileController new]; [self.window makeKeyAndVisible];
}
@end
@interface ReadinessHostDelegate : UIResponder <UIApplicationDelegate>
@end
@implementation ReadinessHostDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options { return YES; }
- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)session options:(UISceneConnectionOptions *)options {
 UISceneConfiguration *config=[[UISceneConfiguration alloc] initWithName:@"Readiness" sessionRole:session.role]; config.delegateClass=ReadinessSceneDelegate.class; return config;
}
@end
int main(int argc,char **argv) { @autoreleasepool { return UIApplicationMain(argc,argv,nil,NSStringFromClass(ReadinessHostDelegate.class)); } }
