import plistlib,zipfile,struct,json
from pathlib import Path
r=Path(__file__).resolve().parent
with zipfile.ZipFile(r/'Readiness-WatchBridge-generic-EXPERIMENTAL-unsigned.ipa') as z:
 assert z.testzip() is None
 hroot='Payload/ReadinessHost.app/';wroot=hroot+'Watch/Readiness.app/'
 h=plistlib.loads(z.read(hroot+'Info.plist'));w=plistlib.loads(z.read(wroot+'Info.plist'))
 assert w['WKCompanionAppBundleIdentifier']==h['CFBundleIdentifier']
 assert w['CFBundleIdentifier'].startswith(h['CFBundleIdentifier']+'.')
 assert 'WKWatchOnly' not in w
 assert z.read(hroot+h['CFBundleExecutable'])[:4]==b'\xcf\xfa\xed\xfe'
 bridge=z.read(wroot+'Frameworks/ReadinessBridge.framework/ReadinessBridge')
 assert bridge[0xda9b4:0xda9b8]==bytes.fromhex('03000014')
 # Reproduce WatchBridge bundle.rs identifier rewriting with unrelated teams.
 for team in ['ZQDV929Z94','ABCDEFGHIJ','1234567890']:
  newhost=h['CFBundleIdentifier']+'.'+team
  newwatch=newhost+w['CFBundleIdentifier'][len(h['CFBundleIdentifier']):]
  assert newwatch.startswith(newhost+'.') and newwatch.endswith('.watchkitapp')
  assert bridge[0xda9b4:0xda9b8]==bytes.fromhex('03000014')
 assert not any('mobileprovision' in n or '_CodeSignature' in n for n in z.namelist())
 print('PASS: companion structure, executable, generic bridge guard, three independent team rewrites, no profiles or signatures')
