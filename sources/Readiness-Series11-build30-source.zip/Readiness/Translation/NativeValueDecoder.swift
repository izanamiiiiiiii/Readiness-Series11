import Foundation

/// A decoder over real, typed input values. Unlike a schema recorder this never
/// invents defaults, numbers, booleans, collection entries, or object instances.
indirect enum NativeValue {
    case null
    case value(Any)
    case object([String: NativeValue])
    case array([NativeValue])
}

struct NativeValueDecoder: Decoder {
    let input: NativeValue
    var codingPath: [any CodingKey] = []
    var userInfo: [CodingUserInfoKey: Any] = [:]

    func child(_ input: NativeValue, key: any CodingKey) -> Self {
        Self(input: input, codingPath: codingPath + [key], userInfo: userInfo)
    }

    func decode<T: Decodable>(_ type: T.Type) throws -> T {
        if case .value(let realValue) = input, let exact = realValue as? T {
            return exact
        }
        return try T(from: self)
    }

    func container<Key: CodingKey>(keyedBy: Key.Type) throws -> KeyedDecodingContainer<Key> {
        guard case .object(let entries) = input else { throw mismatch([String: Any].self) }
        return KeyedDecodingContainer(Keys(decoder: self, entries: entries))
    }

    func unkeyedContainer() throws -> any UnkeyedDecodingContainer {
        guard case .array(let entries) = input else { throw mismatch([Any].self) }
        return Items(decoder: self, entries: entries)
    }

    func singleValueContainer() throws -> any SingleValueDecodingContainer {
        Single(decoder: self)
    }

    func mismatch(_ type: Any.Type) -> DecodingError {
        .typeMismatch(type, .init(codingPath: codingPath, debugDescription: "Real input has a different native type or container shape"))
    }

    struct Keys<Key: CodingKey>: KeyedDecodingContainerProtocol {
        let decoder: NativeValueDecoder
        let entries: [String: NativeValue]
        var codingPath: [any CodingKey] { decoder.codingPath }
        var allKeys: [Key] { entries.keys.sorted().compactMap(Key.init(stringValue:)) }
        func contains(_ key: Key) -> Bool { entries[key.stringValue] != nil }
        func decodeNil(forKey key: Key) throws -> Bool {
            if case .null = try entry(key) { return true }
            return false
        }
        func entry(_ key: Key) throws -> NativeValue {
            guard let value = entries[key.stringValue] else {
                throw DecodingError.keyNotFound(key, .init(codingPath: codingPath, debugDescription: "No real value supplied for this required native field"))
            }
            return value
        }
        func decode<T: Decodable>(_ type: T.Type, forKey key: Key) throws -> T {
            try decoder.child(entry(key), key: key).decode(type)
        }
        func nestedContainer<NestedKey: CodingKey>(keyedBy: NestedKey.Type, forKey key: Key) throws -> KeyedDecodingContainer<NestedKey> {
            try decoder.child(entry(key), key: key).container(keyedBy: keyedBy)
        }
        func nestedUnkeyedContainer(forKey key: Key) throws -> any UnkeyedDecodingContainer {
            try decoder.child(entry(key), key: key).unkeyedContainer()
        }
        func superDecoder() throws -> any Decoder { decoder }
        func superDecoder(forKey key: Key) throws -> any Decoder { try decoder.child(entry(key), key: key) }
    }

    struct Items: UnkeyedDecodingContainer {
        let decoder: NativeValueDecoder
        let entries: [NativeValue]
        var codingPath: [any CodingKey] { decoder.codingPath }
        var count: Int? { entries.count }
        var isAtEnd: Bool { currentIndex == entries.count }
        var currentIndex = 0
        mutating func take() throws -> NativeValueDecoder {
            guard !isAtEnd else {
                throw DecodingError.valueNotFound(Any.self, .init(codingPath: codingPath, debugDescription: "Real input array ended"))
            }
            let key = Index(intValue: currentIndex)!
            defer { currentIndex += 1 }
            return decoder.child(entries[currentIndex], key: key)
        }
        mutating func decodeNil() throws -> Bool {
            guard !isAtEnd else { return false }
            if case .null = entries[currentIndex] { currentIndex += 1; return true }
            return false
        }
        mutating func decode<T: Decodable>(_ type: T.Type) throws -> T { try take().decode(type) }
        mutating func nestedContainer<NestedKey: CodingKey>(keyedBy: NestedKey.Type) throws -> KeyedDecodingContainer<NestedKey> { try take().container(keyedBy: keyedBy) }
        mutating func nestedUnkeyedContainer() throws -> any UnkeyedDecodingContainer { try take().unkeyedContainer() }
        mutating func superDecoder() throws -> any Decoder { try take() }
    }

    struct Single: SingleValueDecodingContainer {
        let decoder: NativeValueDecoder
        var codingPath: [any CodingKey] { decoder.codingPath }
        func decodeNil() -> Bool { if case .null = decoder.input { return true }; return false }
        func decode<T: Decodable>(_ type: T.Type) throws -> T {
            guard case .value(let real) = decoder.input, let exact = real as? T else { throw decoder.mismatch(type) }
            return exact
        }
    }

    struct Index: CodingKey {
        let stringValue: String
        let intValue: Int?
        init?(stringValue: String) { self.stringValue = stringValue; intValue = Int(stringValue) }
        init?(intValue: Int) { self.intValue = intValue; stringValue = String(intValue) }
    }
}
