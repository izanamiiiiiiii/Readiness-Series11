import Foundation
import HealthKit
import HealthBalance

/// Adapts the verified public reader schema; no private health queries.
public enum PublicNightBridgeBuilder {
    public static func translate(_ inputs: PublicReadinessInputs, rmssdByMorning: [Date: Double], calendar: Calendar) throws -> [HealthBalance.SleepingSampleDaySummary] {
        let nights = inputs.nights.sorted { $0.morningDate < $1.morningDate }
        return try nights.map { night in
            let previous = nights.filter { $0.morningDate < night.morningDate }
            let start = inputs.requestedWindow.start
            func metric(_ signal: PublicInputSignal, history: [PublicInputSignal]) throws -> PublicNightNativeTranslator.Metric {
                let unit: HKUnit
                switch signal.unit {
                case "count/min": unit = .count().unitDivided(by: .minute())
                case "degC-absolute", "degC", "°C", "degC (absolute)": unit = .degreeCelsius()
                case "fraction", "0...1", "%": unit = .percent()
                case "h", "hours": unit = .hour()
                case "s", "seconds": unit = .second()
                default: throw PublicNightNativeTranslator.TranslationError.invalidObservation("Unknown public unit: \(signal.unit)")
                }
                let provenance = "\(signal.typeIdentifier); \(signal.aggregation); \(signal.sources.map { $0.source.bundleIdentifier }.joined(separator: ","))"
                let values = history.compactMap(\.value).filter(\.isFinite).sorted()
                let baseline: PublicNightNativeTranslator.BaselineStatus
                if values.count < 3 {
                    baseline = values.isEmpty ? .noData(required: 3) : .insufficientData(count: values.count, required: 3)
                } else {
                    func q(_ fraction: Double) -> Double {
                        let location = Double(values.count - 1) * fraction
                        let lower = Int(location), upper = min(values.count-1, Int(location)+1)
                        return values[lower] + (values[upper]-values[lower]) * (location-Double(lower))
                    }
                    let first = q(0.25), third = q(0.75), middle = q(0.5), iqr = third-first
                    let baselineValue = try PublicNightNativeTranslator.DerivedBaseline(
                        unit: unit, middle: middle, medialRange: first...third,
                        typicalRange: (first-1.5*iqr)...(third+1.5*iqr),
                        iqrTypicalRange: (first-1.5*iqr)...(third+1.5*iqr), iqr: iqr,
                        iqrMedialRange: first...third, methodLabel: "local linear quartiles; Tukey 1.5 IQR; prior observed nights")
                    baseline = .available(count: values.count, baseline: baselineValue)
                }
                guard signal.failures.isEmpty else {
                    throw PublicNightNativeTranslator.TranslationError.invalidObservation("Query failure for \(signal.typeIdentifier)")
                }
                return try .init(unit: signal.value == nil ? nil : unit, value: signal.value,
                    sampleInterval: signal.observedWindow, latestCreationDate: nil,
                    availability: signal.value == nil ? .noData : .available, sampleCount: signal.count,
                    sourceFlags: .explicitlyUnclassified(publicSourceProvenance: provenance),
                    baseline: baseline, baselineContainsGen4Data: false, publicQueryProvenance: provenance)
            }
            let rmssd = rmssdByMorning[night.morningDate]
            let validRMSSD = rmssd.flatMap { $0.isFinite && $0 > 0 ? $0 : nil }
            let previousRMSSD = rmssdByMorning.filter { $0.key < night.morningDate }.map(\.value).filter { $0.isFinite && $0 > 0 }.sorted()
            let rmssdBaseline: PublicNightNativeTranslator.BaselineStatus
            if previousRMSSD.count < 3 {
                rmssdBaseline = previousRMSSD.isEmpty ? .noData(required: 3) : .insufficientData(count: previousRMSSD.count, required: 3)
            } else {
                func q(_ f: Double) -> Double {
                    let x = Double(previousRMSSD.count-1)*f, i = Int(x)
                    return previousRMSSD[i] + (previousRMSSD[min(i+1, previousRMSSD.count-1)]-previousRMSSD[i])*(x-Double(i))
                }
                let q1=q(0.25), q3=q(0.75), iqr=q3-q1
                rmssdBaseline = .available(count: previousRMSSD.count, baseline: try .init(unit: .secondUnit(with: .milli), middle: q(0.5), medialRange: q1...q3, typicalRange: (q1-1.5*iqr)...(q3+1.5*iqr), iqrTypicalRange: (q1-1.5*iqr)...(q3+1.5*iqr), iqr: iqr, iqrMedialRange: q1...q3, methodLabel: "local RMSSD prior-night quartiles; Tukey 1.5 IQR"))
            }
            let translatedHRV = try PublicNightNativeTranslator.Metric(unit: validRMSSD == nil ? nil : .secondUnit(with: .milli), value: validRMSSD,
                sampleInterval: nil, latestCreationDate: nil, availability: validRMSSD == nil ? .noData : .available, sampleCount: validRMSSD == nil ? 0 : 1,
                sourceFlags: .explicitlyUnclassified(publicSourceProvenance: "validated heartbeat adapter; one locally derived overnight RMSSD aggregate"),
                baseline: rmssdBaseline, baselineContainsGen4Data: false,
                publicQueryProvenance: "validated heartbeat adapter; one locally derived overnight RMSSD aggregate")
            let mapped = PublicNightNativeTranslator.Night(morning: night.morningDate,
                baselineStart: start, baselineEndExclusive: night.morningDate, latestBaselineSampleEnd: nil,
                heartRate: try metric(night.heartRate, history: previous.map(\.heartRate)),
                bloodOxygen: try metric(night.oxygenSaturation, history: previous.map(\.oxygenSaturation)),
                respiratoryRate: try metric(night.respiratoryRate, history: previous.map(\.respiratoryRate)),
                wristTemperature: try metric(night.wristTemperature, history: previous.map(\.wristTemperature)),
                timeAsleep: try metric(night.sleepDuration, history: previous.map(\.sleepDuration)),
                heartRateVariability: translatedHRV)
            return try PublicNightNativeTranslator.translate(mapped, gregorianCalendar: calendar,
                sourcePolicy: .allowExplicitlyUnclassifiedPresentation)
        }
    }
}
