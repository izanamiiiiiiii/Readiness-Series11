import Foundation
import HealthKit
import HealthBalance

/// Maps measured public-data aggregates and explicitly labelled, independently
/// derived baselines into the real native Decodable day-summary type. It does
/// not perform any query and does not replace failed decoding with a model.
public enum PublicNightNativeTranslator {
    public enum TranslationError: Error {
        case invalidObservation(String)
        case missingProvenance(String)
        case nativeDecodableUnavailable(String)
        case nativeTypeMismatch(String)
    }

    public enum AggregateAvailability: String {
        case noData, insufficientData, insufficientBaselineData, establishingBaselineData, available
    }

    public enum SourcePolicy {
        case requireVerifiedClassification
        /// Empty native OptionSet classifies no source attributes. It does not
        /// erase values, samples, or their public provenance. Native source-
        /// dependent presentation still needs on-device verification.
        case allowExplicitlyUnclassifiedPresentation
    }

    /// Raw native flags must have an independently verified mapping. These flags
    /// are not inferred from Watch model names, guessed sensor generations, or
    /// replaced by zero when their meaning is unknown.
    public struct VerifiedSourceFlags {
        public let rawValue: Int
        public let mappingEvidence: String
        public let isVerifiedClassification: Bool
        public init(verifiedRawValue: Int, mappingEvidence: String) throws {
            guard !mappingEvidence.isEmpty else { throw TranslationError.missingProvenance("native source flags") }
            rawValue = verifiedRawValue
            self.mappingEvidence = mappingEvidence
            isVerifiedClassification = true
        }
        private init(unclassifiedProvenance: String) {
            rawValue = 0
            mappingEvidence = unclassifiedProvenance
            isVerifiedClassification = false
        }
        /// Zero here is the empty OptionSet of native classification flags,
        /// not an invented sensor generation or a claim of zero measurements.
        public static func explicitlyUnclassified(publicSourceProvenance: String) throws -> Self {
            guard !publicSourceProvenance.isEmpty else { throw TranslationError.missingProvenance("public source provenance") }
            return Self(unclassifiedProvenance: publicSourceProvenance)
        }
    }

    public struct DerivedBaseline {
        public let unit: HKUnit
        public let middle: Double
        public let medialRange: ClosedRange<Double>
        public let typicalRange: ClosedRange<Double>
        public let iqrTypicalRange: ClosedRange<Double>
        public let iqr: Double
        public let iqrMedialRange: ClosedRange<Double>
        public let methodLabel: String
        public init(unit: HKUnit, middle: Double, medialRange: ClosedRange<Double>, typicalRange: ClosedRange<Double>, iqrTypicalRange: ClosedRange<Double>, iqr: Double, iqrMedialRange: ClosedRange<Double>, methodLabel: String) throws {
            guard !methodLabel.isEmpty else { throw TranslationError.missingProvenance("baseline method") }
            guard middle.isFinite, iqr.isFinite, iqr >= 0,
                  [medialRange, typicalRange, iqrTypicalRange, iqrMedialRange].allSatisfy({ $0.lowerBound.isFinite && $0.upperBound.isFinite }) else {
                throw TranslationError.invalidObservation("baseline numeric fields")
            }
            self.unit = unit; self.middle = middle; self.medialRange = medialRange
            self.typicalRange = typicalRange; self.iqrTypicalRange = iqrTypicalRange
            self.iqr = iqr; self.iqrMedialRange = iqrMedialRange; self.methodLabel = methodLabel
        }
    }

    public enum BaselineStatus {
        case noData(required: Int)
        case insufficientData(count: Int, required: Int)
        case available(count: Int, baseline: DerivedBaseline)
    }

    public struct Metric {
        public let unit: HKUnit?
        public let value: Double?
        public let sampleInterval: DateInterval?
        public let latestCreationDate: Date?
        public let availability: AggregateAvailability
        public let sampleCount: Int
        public let sourceFlags: VerifiedSourceFlags
        public let baseline: BaselineStatus
        public let baselineContainsGen4Data: Bool
        public let publicQueryProvenance: String
        public init(unit: HKUnit?, value: Double?, sampleInterval: DateInterval?, latestCreationDate: Date?, availability: AggregateAvailability, sampleCount: Int, sourceFlags: VerifiedSourceFlags, baseline: BaselineStatus, baselineContainsGen4Data: Bool, publicQueryProvenance: String) throws {
            guard !publicQueryProvenance.isEmpty else { throw TranslationError.missingProvenance("public query") }
            guard sampleCount >= 0, value?.isFinite != false else { throw TranslationError.invalidObservation("sample count/value") }
            if availability == .available && (sampleCount == 0 || value == nil || unit == nil) {
                throw TranslationError.invalidObservation("available metric requires measured value, unit and samples")
            }
            if availability == .noData && (sampleCount != 0 || value != nil) {
                throw TranslationError.invalidObservation("noData contradicts measured samples")
            }
            self.unit = unit; self.value = value; self.sampleInterval = sampleInterval
            self.latestCreationDate = latestCreationDate; self.availability = availability
            self.sampleCount = sampleCount; self.sourceFlags = sourceFlags; self.baseline = baseline
            self.baselineContainsGen4Data = baselineContainsGen4Data; self.publicQueryProvenance = publicQueryProvenance
        }
    }

    public struct Night {
        public let morning: Date
        public let baselineStart: Date
        public let baselineEndExclusive: Date
        public let latestBaselineSampleEnd: Date?
        public let heartRate: Metric
        public let bloodOxygen: Metric
        public let respiratoryRate: Metric
        public let wristTemperature: Metric
        public let timeAsleep: Metric
        public let heartRateVariability: Metric
        public init(morning: Date, baselineStart: Date, baselineEndExclusive: Date, latestBaselineSampleEnd: Date?, heartRate: Metric, bloodOxygen: Metric, respiratoryRate: Metric, wristTemperature: Metric, timeAsleep: Metric, heartRateVariability: Metric) {
            self.morning = morning; self.baselineStart = baselineStart; self.baselineEndExclusive = baselineEndExclusive
            self.latestBaselineSampleEnd = latestBaselineSampleEnd; self.heartRate = heartRate
            self.bloodOxygen = bloodOxygen; self.respiratoryRate = respiratoryRate
            self.wristTemperature = wristTemperature; self.timeAsleep = timeAsleep; self.heartRateVariability = heartRateVariability
        }
    }

    public static func translate(_ night: Night, gregorianCalendar: Calendar, sourcePolicy: SourcePolicy = .requireVerifiedClassification) throws -> HealthBalance.SleepingSampleDaySummary {
        guard gregorianCalendar.identifier == .gregorian, night.baselineStart <= night.baselineEndExclusive else {
            throw TranslationError.invalidObservation("calendar/baseline date range")
        }
        if case .requireVerifiedClassification = sourcePolicy,
           metrics(in: night).contains(where: { !$0.sourceFlags.isVerifiedClassification }) {
            throw TranslationError.missingProvenance("native source classification; explicit presentation policy required")
        }
        let morning = HealthKit.DayIndex(date: night.morning, calendar: gregorianCalendar)
        let lower = HealthKit.DayIndex(date: night.baselineStart, calendar: gregorianCalendar)
        let upper = HealthKit.DayIndex(date: night.baselineEndExclusive, calendar: gregorianCalendar)
        let analyzedRange = lower..<upper
        let fields: [String: NativeValue] = [
            "morningIndex": .value(morning),
            "baselineRange": .value(analyzedRange),
            "latestBaselineSampleEnd": optional(night.latestBaselineSampleEnd),
            // No elevation/cycle context has been established from these inputs.
            // This optional field is intentionally absent, not a fabricated flag.
            "outlierContext": .null,
            "heartRate": try comparison(night.heartRate, morning: morning, range: analyzedRange),
            "bloodOxygen": try comparison(night.bloodOxygen, morning: morning, range: analyzedRange),
            "respiratoryRate": try comparison(night.respiratoryRate, morning: morning, range: analyzedRange),
            "wristTemperature": try comparison(night.wristTemperature, morning: morning, range: analyzedRange),
            "_timeAsleep": try comparison(night.timeAsleep, morning: morning, range: analyzedRange),
            "heartRateVariability": try comparison(night.heartRateVariability, morning: morning, range: analyzedRange)
        ]
        return try decodeNative(HealthBalance.SleepingSampleDaySummary.self, input: .object(fields))
    }

    /// Display or retain these beside the engine's real provenance. A successful
    /// native decode does not authenticate an Apple baseline or classification.
    public static func interpretationWarnings(for night: Night) -> [String] {
        var warnings = ["Outlier context was not evaluated; no native outlier-context flag was supplied."]
        if metrics(in: night).contains(where: { !$0.sourceFlags.isVerifiedClassification }) {
            warnings.append("Native source-classification flags are empty because their mapping is unavailable; measured values, counts, units and public source provenance are retained. Source-dependent native visibility remains experimental.")
        }
        let methods = metrics(in: night).compactMap { metric -> String? in
            if case .available(_, let baseline) = metric.baseline { return baseline.methodLabel }
            return nil
        }
        warnings += Set(methods).sorted().map { "Independently derived baseline: \($0). This is not Apple's baseline algorithm." }
        return warnings
    }

    private static func metrics(in night: Night) -> [Metric] {
        [night.heartRate, night.bloodOxygen, night.respiratoryRate, night.wristTemperature, night.timeAsleep, night.heartRateVariability]
    }

    private static func comparison(_ metric: Metric, morning: HealthKit.DayIndex, range: Range<HealthKit.DayIndex>) throws -> NativeValue {
        let baseline: NativeValue
        let availability: NativeValue
        switch metric.baseline {
        case .noData(let required):
            guard required > 0 else { throw TranslationError.invalidObservation("required baseline count") }
            baseline = .null
            availability = .object(["noData": .object(["required": .value(required)])])
        case .insufficientData(let count, let required):
            guard count >= 0, required > count else { throw TranslationError.invalidObservation("insufficient baseline count") }
            baseline = .null
            availability = .object(["insufficientData": .object(["analyzedRange": .value(range), "count": .value(count), "required": .value(required)])])
        case .available(let count, let real):
            guard count > 0 else { throw TranslationError.invalidObservation("available baseline count") }
            baseline = .object(["unit": .value(real.unit), "middleValue": .value(real.middle),
                                "medialValueRange": .value(real.medialRange), "typicalValueRange": .value(real.typicalRange),
                                "iqrTypicalValueRange": .value(real.iqrTypicalRange), "iqrValue": .value(real.iqr),
                                "iqrMedialValueRange": .value(real.iqrMedialRange)])
            availability = .object(["available": .object(["analyzedRange": .value(range), "count": .value(count)])])
        }
        let aggregate = NativeValue.object([
            "morningIndex": .value(morning), "unit": optional(metric.unit), "value": optional(metric.value),
            "sampleDateInterval": optional(metric.sampleInterval), "latestSampleCreationDate": optional(metric.latestCreationDate),
            "availability": .object([metric.availability.rawValue: .object([:])]),
            "sampleCount": .value(metric.sampleCount), "dataSources": .value(metric.sourceFlags.rawValue)
        ])
        return .object(["aggregate": aggregate, "availability": availability, "baseline": baseline,
                        "anyBaselineAggregateContainsGen4Data": .value(metric.baselineContainsGen4Data)])
    }

    private static func optional<T>(_ value: T?) -> NativeValue {
        if let value { return .value(value) }
        return .null
    }

    private static func decodeNative<T>(_ expected: T.Type, input: NativeValue) throws -> T {
        let name = "13HealthBalance24SleepingSampleDaySummaryV"
        guard let runtime = _typeByName(name), ObjectIdentifier(runtime) == ObjectIdentifier(expected),
              let decodable = runtime as? any Decodable.Type else {
            throw TranslationError.nativeDecodableUnavailable(name)
        }
        let actual = try decodable.init(from: NativeValueDecoder(input: input))
        guard let typed = actual as? T else { throw TranslationError.nativeTypeMismatch(name) }
        return typed
    }
}
