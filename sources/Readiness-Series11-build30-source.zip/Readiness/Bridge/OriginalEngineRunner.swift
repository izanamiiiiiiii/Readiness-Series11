import Foundation
import HealthKit
import WorkoutCore
import HealthBalance
import HealthBalanceUI

/// Public read-only engine pipeline inside the original Cobalt process.
/// A historical result is never silently presented as today's score.
@MainActor enum OriginalEngineRunner {
    private static var started = false
    private(set) static var state = "notStarted"
    private(set) static var published = false
    private(set) static var scorePublished = false
    private(set) static var nights = 0
    private(set) static var effortReadStatus = "notStarted"
    private(set) static var overnightPublished = false
    private(set) static var metricsState = "notStarted"
    private(set) static var experimentalOutliers: [String] = []
    private(set) static var observedActivityDays = 0

    static func startIfReady() {
        guard !started, CobaltOriginalBridge.capturedProviderBelongsToModel == true else { return }
        started = true
        state = "readingPublicHealthKit"
        writeReport()
        Task {
            do {
                let now = Date()
                let calendar = Calendar.current
                let history = try await Task.detached(priority: .userInitiated) {
                    try await HealthKitReadinessAdapter().fetchOvernightHistory()
                }.value
                nights = history.count
                var native: WorkoutCore.ReadinessScoreModel?
                if let today = history.first(where: { calendar.isDate($0.morningDate, inSameDayAs: now) }) {
                    let result = RobustReadinessEngine.evaluate(history: history.filter { $0.morningDate < today.morningDate }, today: today, referenceDate: now)
                    switch result.state {
                    case .ready(let score, _):
                        // Explicit own-engine normalization from 0...100 to -1...1.
                        // Native presentation helpers determine the 0...10 bucket
                        // and category. This does not invoke Apple's scoring engine.
                        let normalized = Double(score) / 50 - 1
                        guard let scaled = WorkoutCore.ReadinessCategory.scaledScore(from: normalized) else {
                            throw ReadinessFailure.message("Native presentation rejected the normalized own-engine result")
                        }
                        let category = WorkoutCore.ReadinessCategory.category(for: scaled)
                        // Decompose the same existing weighted formula. These
                        // are signed contributions, not 0...100 factor scores.
                        let totalWeight = result.factors.reduce(0) { $0 + $1.weight }
                        func contribution(_ factors: [FactorEvaluation]) -> Double? {
                            guard !factors.isEmpty, totalWeight > 0 else { return nil }
                            return factors.reduce(0) { $0 + ($1.componentScore / 50 - 1) * $1.weight / totalWeight }
                        }
                        let physiological = result.factors.filter { $0.name != "Sueño" }
                        let sleep = result.factors.filter { $0.name == "Sueño" }
                        let vitalsContribution = contribution(physiological)
                        let sleepContribution = contribution(sleep)
                        native = WorkoutCore.ReadinessScoreModel(score: normalized, scaledScore: scaled, category: category, activityComponent: nil, activityDrivingFactor: nil, vitalsComponent: vitalsContribution, overnightVitalsComponent: vitalsContribution, overnightVitalsSubscores: nil, daytimeVitalsComponent: nil, sleepScoreComponent: sleepContribution, sleepSubscores: nil, algorithmVersion: RobustReadinessEngine.formulaVersion + ".normalized-native-presentation", sleepScoreComparison: nil)
                        state = "ownEngineReady"
                        scorePublished = true
                    case .calibrating(let available, let required):
                        state = "calibrating:\(available)/\(required)"
                    case .insufficientData: state = "insufficientQualityInputs"
                    case .error(let message): throw ReadinessFailure.message(message)
                    }
                } else {
                    state = "noNightForToday"
                }
                // nil is the actual completed no-score result, never a fallback number.
                guard CobaltOriginalBridge.capturedProviderBelongsToModel == true else {
                    state = "providerIdentityLost"; writeReport(); return
                }
                try CapturedProviderBridge.publishCompleted(native)
                // Cobalt's original view suppresses results whose scoreUpdated
                // timestamp is stale. Commit the actual completion timestamp
                // through its Observation setter after publishing the real result.
                try CobaltOriginalBridge.markPublicResultCompleted(at: Date())
                published = true
                writeReport()
                await publishMeasuredMetrics(history: history)
            } catch {
                state = "failed:\(error.localizedDescription)"
                // A failed public read is a completed no-score state, never
                // an indefinite native spinner or a made-up cached score.
                try? CapturedProviderBridge.publishCompleted(nil)
                try? CobaltOriginalBridge.markPublicResultCompleted(at: Date())
                writeReport()
            }
        }
    }

    private static func publishMeasuredMetrics(history: [OvernightSummary]) async {
        metricsState = "readingPublicMetrics"; writeReport()
        do {
            let inputs = try await PublicHealthKitInputsReader(store: HKHealthStore()).fetch(days: 35)
            var calendar = Calendar(identifier: .gregorian)
            calendar.timeZone = .current
            var rmssd: [Date: Double] = [:]
            for night in history { if let value = night.rmssdMs { rmssd[night.morningDate] = value } }
            MeasuredCardText.refresh(from: inputs, calendar: calendar)
            observedActivityDays = inputs.activityDays.filter { $0.activeEnergy.value != nil && $0.activeEnergy.failures.isEmpty }.count
            if let today = inputs.nights.first(where: { calendar.isDateInToday($0.morningDate) }) {
                let previous = inputs.nights.filter { $0.morningDate < today.morningDate }
                func outside(_ current: Double?, previous: [Double]) -> Bool {
                    let values = previous.filter(\.isFinite).sorted()
                    guard let current, current.isFinite, values.count >= 3 else { return false }
                    func q(_ f: Double) -> Double {
                        let x = Double(values.count - 1) * f, i = Int(x)
                        return values[i] + (values[min(i+1, values.count-1)] - values[i]) * (x-Double(i))
                    }
                    let q1 = q(0.25), q3 = q(0.75), iqr = q3-q1
                    return current < q1-1.5*iqr || current > q3+1.5*iqr
                }
                let signals: [(String, KeyPath<PublicNightInputs, PublicInputSignal>)] = [
                    ("heartRate", \.heartRate), ("respiratoryRate", \.respiratoryRate),
                    ("wristTemperature", \.wristTemperature), ("oxygenSaturation", \.oxygenSaturation),
                    ("sleepDuration", \.sleepDuration)]
                experimentalOutliers = signals.compactMap { name, key in
                    outside(today[keyPath: key].value, previous: previous.compactMap { $0[keyPath: key].value }) ? name : nil
                }
                if outside(rmssd[today.morningDate], previous: rmssd.filter { $0.key < today.morningDate }.map(\.value)) {
                    experimentalOutliers.append("locallyDerivedRMSSD")
                }
            }
            let summaries = try PublicNightBridgeBuilder.translate(inputs, rmssdByMorning: rmssd, calendar: calendar)
            let start = HealthKit.DayIndex(date: inputs.requestedWindow.start, calendar: calendar)
            let end = HealthKit.DayIndex(date: inputs.requestedWindow.end, calendar: calendar)
            let range = HealthBalance.GregorianDayRange(dayIndexRange: start...end, gregorianCalendar: calendar)
            let overnight = HealthBalanceUI.OvernightMetricsViewModel(dayRange: range, chronologicalDaySummaries: summaries, featureStatus: nil)
            try CobaltOriginalBridge.publishOvernight(overnight)
            try CobaltOriginalBridge.markPublicResultCompleted(at: Date())
            overnightPublished = true
            metricsState = "published:\(summaries.count) measured nights"
            writeReport()
            if let card = MeasuredCardText.today, card.workoutCount > 0 {
                Task { await refreshFitnessEffort(inputs: inputs, calendar: calendar, overnight: overnight) }
            }
        } catch {
            metricsState = "failed:\(error)"
        }
        writeReport()
    }

    private static func refreshFitnessEffort(
        inputs: PublicReadinessInputs, calendar: Calendar,
        overnight: HealthBalanceUI.OvernightMetricsViewModel
    ) async {
        let health = HKHealthStore()
        effortReadStatus = "requestingReadAccess"
        do {
            try await health.requestAuthorization(toShare: [], read: PublicHealthKitInputsReader.workoutEffortReadTypes)
            effortReadStatus = "reading"
            let effortInputs = try await PublicHealthKitInputsReader(store: health, calendar: calendar)
                .fetch(days: 7, includeWorkoutEffort: true, endingAt: inputs.requestedWindow.end)
            MeasuredCardText.refresh(from: inputs, calendar: calendar, effortInputs: effortInputs)
            try CobaltOriginalBridge.publishOvernight(overnight)
            let audits = effortInputs.queries.filter { $0.operation.contains("Effort") }
            let samples = audits.filter { $0.operation.hasPrefix("direct") }.reduce(0) { $0 + $1.visibleCount }
            let failures = audits.compactMap { $0.failure }.map { "\($0.operation):\($0.domain):\($0.code)" }
            effortReadStatus = "completed; directSamples=\(samples); failures=\(failures.joined(separator: ","))"
        } catch {
            let failure = error as NSError
            effortReadStatus = "failed:\(failure.domain):\(failure.code)"
        }
    }

    static func writeReport() {
        let report: [String: Any] = ["timestamp":Date().timeIntervalSince1970, "state":state, "nights":nights, "published":published, "scorePublished":scorePublished, "method":RobustReadinessEngine.formulaVersion, "writesToHealthKit":false, "overnightPublished":overnightPublished, "metricsState":metricsState, "experimentalOutlierMetrics":experimentalOutliers, "observedActivityDays":observedActivityDays, "outlierMethod":"own prior-night quartiles, not Apple Vitals", "fitnessContributionImplemented":false, "appleSleepScoreRead":false]
        if let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first,
           let data = try? JSONSerialization.data(withJSONObject: report, options: [.sortedKeys]) {
            try? data.write(to:folder.appendingPathComponent("cobalt-public-engine.json"), options:.atomic)
        }
    }
}
