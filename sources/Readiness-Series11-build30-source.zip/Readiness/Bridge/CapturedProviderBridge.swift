import Foundation
import WorkoutCore

/// Captures an existing provider and updates only its genuine exported property
/// setters. It does not construct a provider or suppress the provider's own
/// initializer, automatic fetch, observation tasks, or future updates.
@MainActor
public enum CapturedProviderBridge {
    public enum Failure: Error { case noCapturedProvider }
    private static weak var provider: WorkoutCore.ReadinessDataProvider?
    public static var hasCapturedProvider: Bool { provider != nil }
    public static var diagnosticState: [String: Any] {
        guard let provider else { return ["providerAlive": false] }
        let loading: String
        switch provider.loadingState {
        case .hasntLoaded: loading = "hasntLoaded"
        case .loading: loading = "loading"
        case .loaded: loading = "loaded"
        @unknown default: loading = "unknown"
        }
        return ["loadingState": loading,
                "hasScoreModel": provider.readinessModel != nil,
                "hasRawScore": provider.readinessModel?.score != nil,
                "nativeScoreAvailable": provider.readinessModel?.isScoreAvailable ?? false,
                "hasScaledScore": provider.readinessModel?.scaledScore != nil]
    }
    public static func isCapturedProvider(_ object: AnyObject) -> Bool? {
        guard let provider else { return nil }
        return provider === object
    }

    public static func captureCandidate(_ object: WorkoutCore.ReadinessDataProvider) {
        provider = object
    }

    /// Call only for the public-data engine's completed real result. A nil model
    /// is an explicit result with no score; no arbitrary number is substituted.
    public static func publishCompleted(_ model: WorkoutCore.ReadinessScoreModel?) throws {
        guard let provider else { throw Failure.noCapturedProvider }
        provider.readinessModel = model
        provider.loadingState = .loaded
    }
}

/// C owns the temporary +1 retain through this entire callback. Swift treats
/// this parameter as borrowed, checks exact dynamic metadata and stores weakly.
@_cdecl("cobalt_original_provider_capture")
public func cobaltOriginalProviderCapture(_ object: UnsafeRawPointer?) -> Int32 {
    guard Thread.isMainThread, let object else { return 0 }
    let address = UInt(bitPattern: object)
    return MainActor.assumeIsolated {
        guard let pointer = UnsafeRawPointer(bitPattern: address) else { return 0 }
        let candidate = Unmanaged<AnyObject>.fromOpaque(pointer).takeUnretainedValue()
        guard ObjectIdentifier(Swift.type(of: candidate)) == ObjectIdentifier(WorkoutCore.ReadinessDataProvider.self),
              let provider = candidate as? WorkoutCore.ReadinessDataProvider else { return 0 }
        CapturedProviderBridge.captureCandidate(provider)
        return 1
    }
}
