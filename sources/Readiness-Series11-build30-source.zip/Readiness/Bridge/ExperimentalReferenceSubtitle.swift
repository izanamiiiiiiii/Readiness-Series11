import Foundation
import HealthBalance
import HealthBalanceUI
import WorkoutCore
import WorkoutUI
import os

enum MeasuredCardText {
    struct Snapshot: Sendable {
        let recordedAt: Date
        let sleep: String?
        let fitness: String?
        let workoutCount: Int
        let workoutsWithEffort: Int
        let workoutsWithDurationAndEffort: Int
        let vitals: String?
    }

    private static let latest = OSAllocatedUnfairLock<Snapshot?>(initialState: nil)

    static func refresh(from inputs: PublicReadinessInputs, calendar: Calendar, effortInputs: PublicReadinessInputs? = nil) {
        let now = inputs.requestedWindow.end
        let night = inputs.nights.first { calendar.isDate($0.morningDate, inSameDayAs: now) }
        let activity = inputs.activityDays.first { calendar.isDate($0.day, inSameDayAs: now) }
        func measured(_ signal: PublicInputSignal?) -> Double? {
            guard let signal, signal.failures.isEmpty, signal.count > 0,
                  let value = signal.value, value.isFinite, value >= 0 else { return nil }
            return value
        }
        let sleep = measured(night?.sleepDuration).flatMap { hours -> String? in
            guard hours <= 24 else { return nil }
            let minutes = Int((hours * 60).rounded())
            return "\(minutes / 60) h \(minutes % 60) min de sueño"
        }
        let weekStart = calendar.date(byAdding: .day, value: -6, to: calendar.startOfDay(for: now))
        let recentWorkouts = inputs.workouts.filter { workout in
            guard let weekStart else { return false }
            return workout.window.end >= weekStart && workout.window.end <= now
        }
        let durations = recentWorkouts.compactMap { measured($0.duration) }
        let effortByWorkout = Dictionary(
            (effortInputs?.workouts ?? []).map { ($0.id, $0) },
            uniquingKeysWith: { first, _ in first }
        )
        var workoutsWithEffort = 0
        let weightedMinutes = recentWorkouts.compactMap { workout -> Double? in
            guard let recorded = effortByWorkout[workout.id],
                  let effort = measured(recorded.perceivedEffort) ?? measured(recorded.estimatedEffort),
                  effort <= 10 else { return nil }
            workoutsWithEffort += 1
            guard let duration = measured(workout.duration), duration > 0 else { return nil }
            return (duration / 60) * effort
        }
        let activeEnergy = measured(activity?.activeEnergy).map {
            "\($0.formatted(.number.precision(.fractionLength(0)))) kcal activas hoy"
        }
        let fitness: String?
        if !recentWorkouts.isEmpty, weightedMinutes.count == recentWorkouts.count {
            let load = weightedMinutes.reduce(0, +).formatted(.number.precision(.fractionLength(0)))
            fitness = "\(load) carga registrada · 7 días"
        } else if !durations.isEmpty {
            let minutes = (durations.reduce(0, +) / 60).formatted(.number.precision(.fractionLength(0)))
            fitness = "\(minutes) min de entreno · 7 días"
        } else {
            fitness = activeEnergy
        }
        let vitals = measured(night?.heartRate).map {
            "\($0.formatted(.number.precision(.fractionLength(0)))) lpm durante el sueño"
        }
        let snapshot = Snapshot(recordedAt: now, sleep: sleep, fitness: fitness, workoutCount: recentWorkouts.count, workoutsWithEffort: workoutsWithEffort,
            workoutsWithDurationAndEffort: weightedMinutes.count, vitals: vitals)
        latest.withLock { $0 = snapshot }
    }

    static var today: Snapshot? {
        latest.withLock { snapshot in
            guard let snapshot, Calendar.current.isDateInToday(snapshot.recordedAt) else { return nil }
            return snapshot
        }
    }
}

extension HealthBalanceUI.OvernightMetricsViewModel {
    public var ownBridgeReferenceSubtitle: String {
        @_silgen_name("cobalt_own_overnight_subtitle")
        get {
            guard let value = MeasuredCardText.today?.vitals else { return "Referencia experimental" }
            return value + " · Referencia experimental"
        }
    }
}

extension WorkoutUI.SleepSectionViewModel {
    public var ownBridgeSleepSubtitle: String? {
        @_silgen_name("cobalt_own_sleep_subtitle")
        get { subtitle ?? MeasuredCardText.today?.sleep }
    }
}

extension WorkoutUI.ReadinessActivityStringBuilder {
    @_silgen_name("cobalt_own_fitness_subtitle")
    public static func ownBridgeFitnessSubtitle(for factor: WorkoutCore.WOReadinessActivityFactor?, trainingLoadBand: HealthBalance.TrainingLoadBand?) -> String? {
        detailText(for: factor, trainingLoadBand: trainingLoadBand) ?? MeasuredCardText.today?.fitness
    }
}
