#ifndef COBALT_PROVIDER_CAPTURE_API_H
#define COBALT_PROVIDER_CAPTURE_API_H
#include <stdint.h>
void cobalt_provider_capture_arm_canary(const void *metadata);
uint64_t cobalt_provider_capture_canary_calls(void);
uint64_t cobalt_provider_capture_total_calls(void);
uint64_t cobalt_provider_capture_model_calls(void);
uint64_t cobalt_provider_capture_provider_calls(void);
uint64_t cobalt_provider_capture_candidates(void);
uint64_t cobalt_provider_capture_outside_window(void);
uint32_t cobalt_provider_capture_model_accepted(void);
uint32_t cobalt_provider_capture_provider_accepted(void);
#endif
