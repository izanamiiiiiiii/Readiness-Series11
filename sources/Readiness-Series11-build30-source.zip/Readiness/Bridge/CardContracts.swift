import Foundation
import Darwin
import HealthBalanceUI

@MainActor enum CardContracts {
    private static var inspected = false
    static let visibleTypesConstructor = "$s15HealthBalanceUI25OvernightMetricsViewModelV8dayRange25chronologicalDaySummaries16visibleDataTypesAC0aB009GregoriankI0V_SayAG014SleepingSampleK7SummaryVGSayAG0qrN4TypeOGtcfC"
    static var supportsExplicitVisibility: Bool {
        guard let handle = dlopen("/System/Library/PrivateFrameworks/HealthBalanceUI.framework/HealthBalanceUI", RTLD_LAZY | RTLD_LOCAL) else { return false }
        defer { dlclose(handle) }
        return dlsym(handle, visibleTypesConstructor) != nil
    }
    static func inspect() {
        guard !inspected else { return }
        inspected = true
        var report: [String: Any] = ["explicitVisibilityConstructor":supportsExplicitVisibility]
        report["presentationOverrides"] = UserDefaults.standard.dictionaryRepresentation().filter { key, value in
            ["demo", "fake", "override"].contains(where: { key.lowercased().contains($0) }) && (value is Bool || value is String || value is Int)
        }
        for (module, name) in [("SleepHealth", "SleepScoreDaySummary"), ("SleepHealth", "SleepDaySummary"), ("SleepHealthUI", "SleepScoreModel")] {
            let mangled = "\(module.utf8.count)\(module)\(name.utf8.count)\(name)V"
            guard let type = _typeByName(mangled) else { report[module+"."+name] = "typeUnavailable"; continue }
            guard let decoder = type as? any Decodable.Type else { report[module+"."+name] = "notDecodable"; continue }
            do {
                // Schema discovery only. No candidate is retained or presented.
                _ = try decoder.init(from:RequiredFieldDecoder())
                report[module+"."+name] = "emptyDecodeSucceededInstanceDiscarded"
            } catch {
                report[module+"."+name] = String(reflecting:error)
            }
        }
        if let folder = FileManager.default.urls(for:.documentDirectory,in:.userDomainMask).first,
           let data = try? JSONSerialization.data(withJSONObject:report,options:[.sortedKeys]) {
            try? data.write(to:folder.appendingPathComponent("cobalt-card-contracts.json"),options:.atomic)
        }
    }
}
