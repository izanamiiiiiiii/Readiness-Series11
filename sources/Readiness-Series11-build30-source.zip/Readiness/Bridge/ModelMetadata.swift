import Foundation
import Cobalt

@_cdecl("cobalt_original_model_metadata")
public func cobaltOriginalModelMetadata() -> UnsafeRawPointer? {
    guard Thread.isMainThread else { return nil }
    let bits = MainActor.assumeIsolated {
        UInt(bitPattern: unsafeBitCast(Cobalt.ReadinessModel.self, to: UnsafeRawPointer.self))
    }
    return UnsafeRawPointer(bitPattern: bits)
}
