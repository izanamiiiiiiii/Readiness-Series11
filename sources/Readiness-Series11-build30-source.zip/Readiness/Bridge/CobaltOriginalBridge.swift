import Foundation
import Cobalt
import HealthBalanceUI
import SleepHealthUI
import WorkoutCore
import WorkoutUI

/// Runs inside Cobalt only after its original ReadinessModel has been captured.
/// All writes use verified original property setters (Observation.withMutation),
/// not object offsets. Does not construct providers, query HealthKit or load data.
@MainActor
public enum CobaltOriginalBridge {
    public enum Failure: Error { case noCapturedOriginalModel }
    private static weak var model: Cobalt.ReadinessModel?

    /// The caller is a typed constructor hook that already has a live native model.
    public static func capture(_ original: Cobalt.ReadinessModel) { model = original }
    public static var hasCapturedModel: Bool { model != nil }
    public static var originalResultAgeSeconds: Double? { model.map { abs($0.originalScoreUpdated.timeIntervalSinceNow) } }
    public static var overnightDiagnostic: [String: Any] {
        guard let overnight = model?.originalOvernightMetrics else { return ["present":false] }
        var report: [String: Any] = ["present":true, "hasTodaySummary":overnight.daySummaryForToday != nil,
                "hasDataForReadiness":overnight.hasDataForReadiness,
                "baselineEstablished":overnight.readinessBaselineEstablished]
        for field in Mirror(reflecting: overnight).children {
            guard let label = field.label else { continue }
            if ["visibleDataTypes", "chartPoints", "chronologicalDaySummariesUnconditionallyIncludingSpO2"].contains(label) {
                report[label + "Count"] = Mirror(reflecting:field.value).children.count
            }
            if label == "chartPoints" {
                report["chartPointStates"] = Mirror(reflecting:field.value).children.map { point in
                    var state: [String:Any] = [:]
                    for member in Mirror(reflecting:point.value).children {
                        guard let name = member.label else { continue }
                        if ["hasAnyHighOutliers", "hasAnyTypicalValues", "hasAnyLowOutliers"].contains(name), let flag = member.value as? Bool {
                            state[name] = flag
                        }
                        if name == "determinateValueRange" {
                            state["hasDeterminateRange"] = !Mirror(reflecting:member.value).children.isEmpty
                        }
                    }
                    return state
                }
            }
        }
        return report
    }

    public static func markPublicResultCompleted(at date: Date) throws {
        guard let model else { throw Failure.noCapturedOriginalModel }
        model.originalScoreUpdated = date
    }

    public static func publishOvernight(_ overnight: HealthBalanceUI.OvernightMetricsViewModel) throws {
        guard let model else { throw Failure.noCapturedOriginalModel }
        model.originalOvernightMetrics = overnight
    }

    /// Verify the candidate belongs to the actual original model before publishing.
    /// Reflection reads the field without relying on a guessed storage offset.
    public static var capturedProviderBelongsToModel: Bool? {
        guard let model else { return nil }
        for child in Mirror(reflecting: model).children where child.label == "dataProvider" {
            guard let provider = child.value as? WorkoutCore.ReadinessDataProvider else { return false }
            return CapturedProviderBridge.isCapturedProvider(provider)
        }
        return nil
    }

    /// Nil explicitly represents missing inputs. Apple Sleep Score is never derived here.
    /// This updates presentation fields only; the native data provider is not replaced.
    public static func apply(
        overnight: HealthBalanceUI.OvernightMetricsViewModel?,
        daytime: HealthBalanceUI.DaytimeMetricsViewModel?,
        sleepScore: SleepHealthUI.SleepScoreModel?,
        calculatedAt: Date
    ) throws {
        guard let model else { throw Failure.noCapturedOriginalModel }
        model.originalOvernightMetrics = overnight
        model.originalDaytimeMetrics = daytime
        model.originalSleepScore = sleepScore
        model.originalScoreUpdated = calculatedAt
    }
}

/// Optional C hook boundary. The pointer must be a live retained/borrowed Swift
/// object supplied by the original typed constructor hook, never a data address.
/// The owner retains the model; this bridge stores a weak reference.
@_cdecl("cobalt_original_bridge_capture")
public func cobaltOriginalBridgeCapture(_ object: UnsafeRawPointer?) -> Int32 {
    guard Thread.isMainThread, let object else { return 0 }
    let address = UInt(bitPattern: object)
    return MainActor.assumeIsolated {
        guard let pointer = UnsafeRawPointer(bitPattern: address) else { return 0 }
        let candidate = Unmanaged<AnyObject>.fromOpaque(pointer).takeUnretainedValue()
        guard let model = candidate as? Cobalt.ReadinessModel else { return 0 }
        CobaltOriginalBridge.capture(model)
        return 1
    }
}
