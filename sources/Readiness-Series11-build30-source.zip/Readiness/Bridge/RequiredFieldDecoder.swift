import Foundation

/// Stops at the first required field and reports its runtime type. It never
/// constructs dummy values, supplies samples or produces a presentation model.
struct RequiredFieldDecoder: Decoder {
    var codingPath: [any CodingKey] = []
    var userInfo: [CodingUserInfoKey:Any] = [:]
    func container<Key: CodingKey>(keyedBy: Key.Type) throws -> KeyedDecodingContainer<Key> {
        KeyedDecodingContainer(Fields<Key>())
    }
    func unkeyedContainer() throws -> any UnkeyedDecodingContainer { throw Stop(message:"unkeyed root") }
    func singleValueContainer() throws -> any SingleValueDecodingContainer { throw Stop(message:"single root") }
    struct Stop: Error, CustomStringConvertible {
        let message: String
        var description: String { message }
    }
    struct Fields<Key: CodingKey>: KeyedDecodingContainerProtocol {
        var codingPath: [any CodingKey] = []
        var allKeys: [Key] = []
        func contains(_ key: Key) -> Bool { true }
        func decodeNil(forKey key: Key) throws -> Bool { false }
        func decode<T: Decodable>(_ type: T.Type, forKey key: Key) throws -> T {
            throw Stop(message:"required field \(key.stringValue): \(String(reflecting:type))")
        }
        func nestedContainer<N: CodingKey>(keyedBy type: N.Type, forKey key:Key) throws -> KeyedDecodingContainer<N> { throw Stop(message:"nested \(key.stringValue)") }
        func nestedUnkeyedContainer(forKey key:Key) throws -> any UnkeyedDecodingContainer { throw Stop(message:"array \(key.stringValue)") }
        func superDecoder() throws -> any Decoder { throw Stop(message:"super") }
        func superDecoder(forKey key:Key) throws -> any Decoder { throw Stop(message:"super \(key.stringValue)") }
    }
}
