// REPLACEMENT for ModelAllocationCapture.c, not an additional interposer.
// Compile/link only for the existing isolated arm64 experiment. Never installed
// or executed during preparation. All counters report observations, not a claim
// that dyld permits interposing or that a provider belongs to the model.
#include <stddef.h>
#include <stdint.h>
#include <stdatomic.h>
#include <pthread.h>
#include <dispatch/dispatch.h>

#include "dyld-interposing.h"

// swift_allocObject has the default C ABI in Swift Runtime/HeapObject.h.
// Plain C retain/release calls conservatively assume ordinary caller-clobbered
// registers. Do not add preserve_most to an externally/lazily bound call.
extern void *swift_allocObject(const void *, size_t, size_t);
extern void *swift_retain(void *);
extern void swift_release(void *);
extern const void *cobalt_original_model_metadata(void);
extern const void *cobalt_original_provider_metadata(void);
extern int32_t cobalt_original_bridge_capture(const void *);
extern int32_t cobalt_original_provider_capture(const void *);

struct InterposePair { const void *replacement; const void *original; };
static _Atomic(const void *) modelMetadata;
static _Atomic(const void *) providerMetadata;
static _Atomic(const void *) canaryMetadata;
static _Atomic(uint64_t) totalCalls;
static _Atomic(uint64_t) canaryCalls;
static _Atomic(uint64_t) modelCalls;
static _Atomic(uint64_t) providerCalls;
static _Atomic(uint64_t) providerCandidates;
static _Atomic(uint64_t) providerOutsideWindow;
static _Atomic(unsigned) modelClaimed;
static _Atomic(unsigned) windowOpen;
static _Atomic(unsigned) modelAccepted;
static _Atomic(unsigned) providerAccepted;
static _Thread_local unsigned inHook;

static void deliverModel(void *object) {
    // This is a scheduling boundary, not a general Swift initialization witness.
    // Its use requires the selected synchronous, nonfailable initializer to have
    // returned without servicing a nested main run loop.
    atomic_store_explicit(&windowOpen, 0, memory_order_release);
    int32_t accepted = cobalt_original_bridge_capture(object);
    atomic_store_explicit(&modelAccepted, accepted == 1, memory_order_release);
    swift_release(object); // Balance exactly the temporary capture retain.
}

static void deliverProvider(void *object) {
    // Metadata equality identifies a class, not a parent-child relation. A
    // unique temporal candidate is accepted only after the model callback did.
    if (atomic_load_explicit(&providerCandidates, memory_order_acquire) == 1 &&
        atomic_load_explicit(&modelAccepted, memory_order_acquire)) {
        int32_t accepted = cobalt_original_provider_capture(object);
        atomic_store_explicit(&providerAccepted, accepted == 1, memory_order_release);
    }
    swift_release(object);
}

static void *captureAllocation(const void *metadata, size_t size, size_t alignmentMask) {
    ++inHook;
    void *object = swift_allocObject(metadata, size, alignmentMask);
    atomic_fetch_add_explicit(&totalCalls, 1, memory_order_relaxed);
    if (metadata == atomic_load_explicit(&canaryMetadata, memory_order_acquire))
        atomic_fetch_add_explicit(&canaryCalls, 1, memory_order_relaxed);

    if (inHook == 1 && pthread_main_np()) {
        const void *model = atomic_load_explicit(&modelMetadata, memory_order_acquire);
        const void *provider = atomic_load_explicit(&providerMetadata, memory_order_acquire);
        if (model && metadata == model) {
            atomic_fetch_add_explicit(&modelCalls, 1, memory_order_relaxed);
            unsigned expected = 0;
            if (atomic_compare_exchange_strong_explicit(&modelClaimed, &expected, 1,
                                                       memory_order_acq_rel, memory_order_relaxed)) {
                atomic_store_explicit(&windowOpen, 1, memory_order_release);
                swift_retain(object);
                dispatch_async_f(dispatch_get_main_queue(), object, deliverModel);
            }
        } else if (provider && metadata == provider) {
            atomic_fetch_add_explicit(&providerCalls, 1, memory_order_relaxed);
            if (atomic_load_explicit(&windowOpen, memory_order_acquire)) {
                uint64_t previous = atomic_fetch_add_explicit(&providerCandidates, 1, memory_order_acq_rel);
                if (previous == 0) {
                    swift_retain(object);
                    dispatch_async_f(dispatch_get_main_queue(), object, deliverProvider);
                }
            } else {
                atomic_fetch_add_explicit(&providerOutsideWindow, 1, memory_order_relaxed);
            }
        }
    }
    --inHook;
    return object;
}

DYLD_INTERPOSE(captureAllocation, swift_allocObject)

__attribute__((constructor)) static void configureCapture(void) {
    if (!pthread_main_np()) return;
    atomic_store_explicit(&modelMetadata, cobalt_original_model_metadata(), memory_order_release);
    atomic_store_explicit(&providerMetadata, cobalt_original_provider_metadata(), memory_order_release);
}

// A real self-test client must be compiled into a DIFFERENT image, ordinarily
// the executable. dyld intentionally lets the interposer call the original from
// its own image. Testing a canary class in this dylib would be misleading.
void cobalt_provider_capture_arm_canary(const void *metadata) {
    atomic_store_explicit(&canaryMetadata, metadata, memory_order_release);
}
uint64_t cobalt_provider_capture_canary_calls(void) { return atomic_load(&canaryCalls); }
uint64_t cobalt_provider_capture_total_calls(void) { return atomic_load(&totalCalls); }
uint64_t cobalt_provider_capture_model_calls(void) { return atomic_load(&modelCalls); }
uint64_t cobalt_provider_capture_provider_calls(void) { return atomic_load(&providerCalls); }
uint64_t cobalt_provider_capture_candidates(void) { return atomic_load(&providerCandidates); }
uint64_t cobalt_provider_capture_outside_window(void) { return atomic_load(&providerOutsideWindow); }
uint32_t cobalt_provider_capture_model_accepted(void) { return atomic_load(&modelAccepted); }
uint32_t cobalt_provider_capture_provider_accepted(void) { return atomic_load(&providerAccepted); }

extern void cobalt_probe_write_report(void);
static void reportCapture(void *unused) {
    static unsigned attempts; cobalt_probe_write_report();
    if (++attempts < 40) dispatch_after_f(dispatch_time(DISPATCH_TIME_NOW, 3*NSEC_PER_SEC), dispatch_get_main_queue(), NULL, reportCapture);
}
__attribute__((constructor)) static void scheduleReport(void) {
 dispatch_after_f(dispatch_time(DISPATCH_TIME_NOW, 3*NSEC_PER_SEC), dispatch_get_main_queue(), NULL, reportCapture);
}
