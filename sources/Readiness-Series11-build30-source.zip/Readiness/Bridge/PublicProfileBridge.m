#import <Foundation/Foundation.h>
#import <HealthKit/HealthKit.h>
#import <objc/runtime.h>
#import <mach-o/dyld.h>
#import <ptrauth.h>

// Record availability only, never the profile values.
static void ProfileDiagnostic(NSString *key, NSDictionary *result) {
    @synchronized ([HKHealthStore class]) {
        NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"public-profile-paths.json"];
        NSData *previous = [NSData dataWithContentsOfFile:path];
        NSMutableDictionary *report = previous ? [[NSJSONSerialization JSONObjectWithData:previous options:0 error:nil] mutableCopy] : nil;
        if (!report) report = [NSMutableDictionary new];
        report[key] = result;
        [[NSJSONSerialization dataWithJSONObject:report options:NSJSONWritingSortedKeys error:nil] writeToFile:path atomically:YES];
    }
}

static HKQuantity *MostRecentAuthorizedQuantity(HKHealthStore *store, HKQuantityType *type, NSError *__autoreleasing *outError) {
    dispatch_semaphore_t done = dispatch_semaphore_create(0);
    __block HKQuantity *quantity = nil;
    __block NSError *queryError = nil;
    HKStatisticsQuery *query = [[HKStatisticsQuery alloc] initWithQuantityType:type quantitySamplePredicate:nil options:HKStatisticsOptionMostRecent completionHandler:^(HKStatisticsQuery *query, HKStatistics *statistics, NSError *error) {
        quantity = statistics.mostRecentQuantity;
        queryError = error;
        dispatch_semaphore_signal(done);
    }];
    [store executeQuery:query];
    BOOL timedOut = dispatch_semaphore_wait(done, dispatch_time(DISPATCH_TIME_NOW, 3*NSEC_PER_SEC)) != 0;
    if (timedOut) [store stopQuery:query];
    ProfileDiagnostic([type.identifier stringByAppendingString:@".statistics"], @{@"readable":@(quantity != nil), @"timedOut":@(timedOut), @"errorDomain":queryError.domain ?: @"", @"errorCode":@(queryError.code)});
    if (outError) *outError = timedOut ? [NSError errorWithDomain:@"ReadinessBridge" code:1 userInfo:nil] : queryError;
    return timedOut ? nil : quantity;
}

// Adapt only this app's private profile getters to consented public samples.
// Do not log, synthesize, or persist quantity values.
static HKQuantity *LatestAuthorizedQuantity(HKHealthStore *store, HKQuantityTypeIdentifier identifier, NSError *__autoreleasing *outError) {
    HKQuantityType *type = [HKObjectType quantityTypeForIdentifier:identifier];
    if (!type) return nil;
    dispatch_semaphore_t done = dispatch_semaphore_create(0);
    __block HKQuantity *quantity = nil;
    __block NSError *queryError = nil;
    HKSampleQuery *query = [[HKSampleQuery alloc] initWithSampleType:type predicate:nil limit:1 sortDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:HKSampleSortIdentifierEndDate ascending:NO]] resultsHandler:^(HKSampleQuery *q, NSArray<HKSample *> *samples, NSError *error) {
        queryError = error;
        HKQuantitySample *sample = (HKQuantitySample *)samples.firstObject;
        if ([sample isKindOfClass:[HKQuantitySample class]]) quantity = sample.quantity;
        dispatch_semaphore_signal(done);
    }];
    [store executeQuery:query];
    if (dispatch_semaphore_wait(done, dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC))) {
        [store stopQuery:query];
        if (outError) *outError = [NSError errorWithDomain:@"ReadinessBridge" code:1 userInfo:@{NSLocalizedDescriptionKey:@"Timed out waiting for an authorized sample"}];
        return nil;
    }
    ProfileDiagnostic([identifier stringByAppendingString:@".sample"], @{@"readable":@(quantity != nil), @"mainThread":@([NSThread isMainThread]), @"errorDomain":queryError.domain ?: @"", @"errorCode":@(queryError.code)});
    if (!quantity && !queryError) return MostRecentAuthorizedQuantity(store, type, outError);
    if (outError) *outError = queryError;
    return quantity;
}

static id Height(HKHealthStore *store, SEL selector, NSError *__autoreleasing *error) {
    ProfileDiagnostic(@"heightGetterInvoked", @{@"called":@YES});
    return LatestAuthorizedQuantity(store, HKQuantityTypeIdentifierHeight, error);
}
static id BodyMass(HKHealthStore *store, SEL selector, NSError *__autoreleasing *error) {
    ProfileDiagnostic(@"bodyMassGetterInvoked", @{@"called":@YES});
    return LatestAuthorizedQuantity(store, HKQuantityTypeIdentifierBodyMass, error);
}

static IMP OriginalClientError;
static IMP OriginalExecuteQuery;
static void ExecuteQueryWithMetadata(HKHealthStore *store, SEL selector, HKQuery *query) {
    NSString *queryClass = NSStringFromClass([query class]);
    // The original providers do not have permission to execute these private
    // queries in this development-signed process. Keep them out of healthd;
    // the public bridge owns readiness completion. Do not fabricate results
    // or intercept public HKSampleQuery/HKHeartbeatSeriesQuery callbacks.
    BOOL originalPrivateQuery = [queryClass hasPrefix:@"HealthBalance."] ||
        [queryClass isEqualToString:@"HKMCAnalysisQuery"] ||
        [queryClass isEqualToString:@"HKMCPregnancyStateQuery"];
    @synchronized ([HKQuery class]) {
        NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"readiness-query-errors.txt"];
        NSString *old = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil] ?: @"";
        NSString *line = [NSString stringWithFormat:@"%@=%@\n", originalPrivateQuery ? @"suppressedOriginalPrivateQuery" : @"execute", queryClass];
        if (old.length < 16384) [[old stringByAppendingString:line] writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
    if (originalPrivateQuery) return;
    if (OriginalExecuteQuery) ((void (*)(id, SEL, id))OriginalExecuteQuery)(store, selector, query);
}
static void ClientQueryError(id query, SEL selector, NSError *error, id queryIdentifier) {
    if (error) {
        NSString *line = [NSString stringWithFormat:@"query=%@ domain=%@ code=%ld\n", NSStringFromClass([query class]), error.domain, (long)error.code];
        @synchronized ([HKQuery class]) {
            NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"readiness-query-errors.txt"];
            NSString *old = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil] ?: @"";
            if (old.length < 16384) [[old stringByAppendingString:line] writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
        }
    }
    if (OriginalClientError) ((void (*)(id, SEL, id, id))OriginalClientError)(query, selector, error, queryIdentifier);
}

// This replaces only Cobalt's SleepTracking onboarding query. Presence of
// consented asleep records is required; missing/denied data remains false.
static BOOL SleepConfiguredFromAuthorizedData(void) {
    HKHealthStore *store = [HKHealthStore new];
    HKCategoryType *type = [HKObjectType categoryTypeForIdentifier:HKCategoryTypeIdentifierSleepAnalysis];
    NSMutableArray *asleep = [NSMutableArray array];
    for (NSNumber *value in @[@1, @3, @4, @5]) {
        [asleep addObject:[HKQuery predicateForCategorySamplesWithOperatorType:NSEqualToPredicateOperatorType value:value.integerValue]];
    }
    NSPredicate *recent = [HKQuery predicateForSamplesWithStartDate:[NSDate dateWithTimeIntervalSinceNow:-30*24*60*60] endDate:nil options:0];
    NSPredicate *predicate = [NSCompoundPredicate andPredicateWithSubpredicates:@[recent, [NSCompoundPredicate orPredicateWithSubpredicates:asleep]]];
    dispatch_semaphore_t done = dispatch_semaphore_create(0);
    __block BOOL found = NO;
    HKSampleQuery *query = [[HKSampleQuery alloc] initWithSampleType:type predicate:predicate limit:1 sortDescriptors:nil resultsHandler:^(HKSampleQuery *q, NSArray<HKSample *> *samples, NSError *error) {
        found = !error && samples.count > 0;
        dispatch_semaphore_signal(done);
    }];
    [store executeQuery:query];
    if (dispatch_semaphore_wait(done, dispatch_time(DISPATCH_TIME_NOW, 3*NSEC_PER_SEC))) {
        [store stopQuery:query]; return NO;
    }
    return found;
}

__attribute__((constructor)) static void InstallReadinessBridge(void) {
    if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"org.example.ReadinessBridge.watchkitapp"]) return;
    uintptr_t slide = (uintptr_t)_dyld_get_image_vmaddr_slide(0);
    uintptr_t *sleepAdapterSlot = (uintptr_t *)(slide + 0x100054b58ULL);
    *sleepAdapterSlot = (uintptr_t)ptrauth_strip((void *)&SleepConfiguredFromAuthorizedData, ptrauth_key_function_pointer);
    Method queryError = class_getInstanceMethod([HKQuery class], NSSelectorFromString(@"client_deliverError:forQuery:"));
    if (queryError && strcmp(method_getTypeEncoding(queryError), "v32@0:8@16@24") == 0) OriginalClientError = method_setImplementation(queryError, (IMP)ClientQueryError);
    Class cls = [HKHealthStore class];
    Method execute = class_getInstanceMethod(cls, @selector(executeQuery:));
    if (execute && strcmp(method_getTypeEncoding(execute), "v24@0:8@16") == 0) OriginalExecuteQuery = method_setImplementation(execute, (IMP)ExecuteQueryWithMetadata);
    NSString *diagnosticPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"readiness-query-errors.txt"];
    [[NSString stringWithFormat:@"query hook=%d execute hook=%d\n", OriginalClientError != NULL, OriginalExecuteQuery != NULL] writeToFile:diagnosticPath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    Method height = class_getInstanceMethod(cls, NSSelectorFromString(@"_heightCharacteristicQuantityWithError:"));
    Method mass = class_getInstanceMethod(cls, NSSelectorFromString(@"_bodyMassCharacteristicQuantityWithError:"));
    ProfileDiagnostic(@"installedGetters", @{@"heightEncoding":height ? @(method_getTypeEncoding(height)) : @"missing", @"bodyMassEncoding":mass ? @(method_getTypeEncoding(mass)) : @"missing"});
    if (height && strcmp(method_getTypeEncoding(height), "@24@0:8^@16") == 0) method_setImplementation(height, (IMP)Height);
    if (mass && strcmp(method_getTypeEncoding(mass), "@24@0:8^@16") == 0) method_setImplementation(mass, (IMP)BodyMass);
}

// Request only public read access to existing profile records. No write types.
__attribute__((constructor)) static void RequestPublicProfileReadAccess(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2*NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        HKHealthStore *health = [HKHealthStore new];
        NSSet *reads = [NSSet setWithObjects:
            [HKObjectType characteristicTypeForIdentifier:HKCharacteristicTypeIdentifierDateOfBirth],
            [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierHeight],
            [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierBodyMass], nil];
        [health requestAuthorizationToShareTypes:[NSSet set] readTypes:reads completion:^(BOOL success, NSError *error) {
            NSISO8601DateFormatter *formatter = [NSISO8601DateFormatter new];
            ProfileDiagnostic(@"platformReadWindow", @{@"earliestPermittedSampleDate": [formatter stringFromDate:health.earliestPermittedSampleDate]});
            if (@available(watchOS 27.0, *)) {
                [health getEarliestAuthorizedSampleDateForTypes:reads completion:^(NSDictionary<HKObjectType *,NSDate *> *dates, NSError *scopeError) {
                    NSMutableDictionary *bounds = [NSMutableDictionary new];
                    for (HKObjectType *type in dates) bounds[type.identifier] = [formatter stringFromDate:dates[type]];
                    ProfileDiagnostic(@"limitedAuthorizationWindows", @{@"bounds":bounds, @"errorDomain":scopeError.domain ?: @"", @"errorCode":@(scopeError.code)});
                }];
            }
            NSDictionary *status = @{@"requestCompleted": @(success), @"errorDomain": error.domain ?: @"", @"errorCode": @(error.code), @"writeTypesRequested": @0};
            NSData *data = [NSJSONSerialization dataWithJSONObject:status options:NSJSONWritingSortedKeys error:nil];
            NSString *folder = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
            [data writeToFile:[folder stringByAppendingPathComponent:@"public-profile-authorization.json"] atomically:YES];
            dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                NSError *birthError = nil, *heightError = nil, *massError = nil;
                NSDateComponents *birth = [health dateOfBirthComponentsWithError:&birthError];
                HKQuantity *height = LatestAuthorizedQuantity(health, HKQuantityTypeIdentifierHeight, &heightError);
                HKQuantity *mass = LatestAuthorizedQuantity(health, HKQuantityTypeIdentifierBodyMass, &massError);
                NSDictionary *readability = @{
                    @"dateOfBirthReadable": @(birth != nil), @"heightReadable": @(height != nil), @"bodyMassReadable": @(mass != nil),
                    @"dateOfBirthError": birthError ? @{@"domain":birthError.domain,@"code":@(birthError.code)} : [NSNull null],
                    @"heightError": heightError ? @{@"domain":heightError.domain,@"code":@(heightError.code)} : [NSNull null],
                    @"bodyMassError": massError ? @{@"domain":massError.domain,@"code":@(massError.code)} : [NSNull null]
                };
                NSData *readData = [NSJSONSerialization dataWithJSONObject:readability options:NSJSONWritingSortedKeys error:nil];
                [readData writeToFile:[folder stringByAppendingPathComponent:@"public-profile-readability.json"] atomically:YES];
            });
        }];
    });
}
