#include "dyld-interposing.h"
// Addresses only: the replacement itself is a Swift property getter with the
// same native Swift String return ABI. C never invokes either function.
extern void originalSubtitle(void) __asm__("_$s15HealthBalanceUI25OvernightMetricsViewModelV07WorkoutC0E24readinessSectionSubtitleSSvg");
extern void ownSubtitle(void) __asm__("_cobalt_own_overnight_subtitle");
DYLD_INTERPOSE(ownSubtitle, originalSubtitle)

extern void originalSleepSubtitle(void) __asm__("_$s9WorkoutUI21SleepSectionViewModelV8subtitleSSSgvg");
extern void ownSleepSubtitle(void) __asm__("_cobalt_own_sleep_subtitle");
DYLD_INTERPOSE(ownSleepSubtitle, originalSleepSubtitle)

extern void originalFitnessSubtitle(void) __asm__("_$s9WorkoutUI30ReadinessActivityStringBuilderV10detailText3for16trainingLoadBandSSSg0A4Core011WOReadinessD6FactorVSg_13HealthBalance08TrainingkL0OSgtFZ");
extern void ownFitnessSubtitle(void) __asm__("_cobalt_own_fitness_subtitle");
DYLD_INTERPOSE(ownFitnessSubtitle, originalFitnessSubtitle)
