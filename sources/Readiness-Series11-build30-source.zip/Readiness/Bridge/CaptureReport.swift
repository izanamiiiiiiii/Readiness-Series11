import Foundation
import ProviderCaptureAPI
@_cdecl("cobalt_probe_write_report")
public func cobaltProbeWriteReport() {
    guard Thread.isMainThread else { return }
    MainActor.assumeIsolated {
        OriginalEngineRunner.startIfReady()
        if OriginalEngineRunner.published { CardContracts.inspect() }
        let report: [String: Any] = [
            "date": Date().timeIntervalSince1970,
            "totalAllocationsObserved": cobalt_provider_capture_total_calls(),
            "modelAllocations": cobalt_provider_capture_model_calls(),
            "providerAllocations": cobalt_provider_capture_provider_calls(),
            "providerCandidates": cobalt_provider_capture_candidates(),
            "modelAccepted": cobalt_provider_capture_model_accepted(),
            "providerAccepted": cobalt_provider_capture_provider_accepted(),
            "modelAlive": CobaltOriginalBridge.hasCapturedModel,
            "providerAlive": CapturedProviderBridge.hasCapturedProvider,
            "providerBelongsToOriginalModel": CobaltOriginalBridge.capturedProviderBelongsToModel.map { $0 as Any } ?? NSNull(),
            "scoreInjected": OriginalEngineRunner.scorePublished,
            "publicEngineState": OriginalEngineRunner.state,
            "currentProvider": CapturedProviderBridge.diagnosticState,
            "effortReadStatus": OriginalEngineRunner.effortReadStatus,
            "recentWorkoutsWithDurationAndEffort": MeasuredCardText.today?.workoutsWithDurationAndEffort as Any? ?? NSNull(),
            "recentWorkoutsWithEffort": MeasuredCardText.today?.workoutsWithEffort as Any? ?? NSNull(),
            "recentWorkoutCount": MeasuredCardText.today?.workoutCount as Any? ?? NSNull(),
            "measuredCardText": [
                "sleep": MeasuredCardText.today?.sleep != nil,
                "fitness": MeasuredCardText.today?.fitness != nil,
                "vitals": MeasuredCardText.today?.vitals != nil
            ],
            "overnightModel": CobaltOriginalBridge.overnightDiagnostic,
            "originalResultAgeSeconds": CobaltOriginalBridge.originalResultAgeSeconds.map { $0 as Any } ?? NSNull(),
            "publicResultPublished": OriginalEngineRunner.published
        ]
        if let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first,
           let data = try? JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys]) {
            try? data.write(to: folder.appendingPathComponent("cobalt-original-capture.json"), options: .atomic)
        }
    }
}
