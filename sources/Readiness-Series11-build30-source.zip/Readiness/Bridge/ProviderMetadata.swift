import Foundation
import WorkoutCore

@_cdecl("cobalt_original_provider_metadata")
public func cobaltOriginalProviderMetadata() -> UnsafeRawPointer? {
    guard Thread.isMainThread else { return nil }
    return unsafeBitCast(WorkoutCore.ReadinessDataProvider.self, to: UnsafeRawPointer.self)
}
