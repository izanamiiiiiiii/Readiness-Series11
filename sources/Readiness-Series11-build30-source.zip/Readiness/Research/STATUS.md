# Avance técnico publicable, compilación 19

Probado solo en Watch7,18, watchOS 27.3 / 24S5284h. Este informe describe pruebas observadas, no una garantía de compatibilidad.

1. La app original portaba la UI, bienvenida y navegación, pero no obtenía puntuación con sus consultas originales.
2. Se capturaron el ReadinessModel real de Cobalt y su ReadinessDataProvider. La identidad padre/proveedor se verificó por reflexión, sin adivinar offsets de almacenamiento.
3. Se publican modelos mediante setters nativos, no escribiendo campos por dirección. El hook de asignación solo captura metadatos exactos, retiene temporalmente y entrega en main actor tras la inicialización síncrona.
4. El motor lee HealthKit público y mantiene caché de series válidas. Se filtran fuentes, datos manuales, gaps, noches duplicadas/antiguas/futuras y latidos fuera del sueño.
5. La vista original requiere puntuación escalada, categoría y fecha reciente. Se completó ese contrato con el resultado real del motor propio; el usuario confirmó el número.
6. Se tradujeron las mediciones nocturnas reales; las comprobaciones nativas confirmaron resumen de hoy, referencia establecida y datos disponibles. El usuario confirmó valores visibles.
7. La referencia propia marcó RMSSD como atípica aunque Apple Vitals no mostraba anomalías. No son la misma referencia. Se agregó la etiqueta experimental; no se forzaron todos los valores a nominal.
8. Sueño y Fitness todavía no están completos. Duración de sueño no equivale a Sleep Score oficial, y calorías no equivalen por sí solas al modelo de Fitness de Apple.

## Próximos pasos

- Modelo de Fitness a partir de actividad real, conservando método, procedencia y disponibilidad.
- Contrato SleepScoreModel / SleepScoreDaySummary sin fabricar puntuación oficial Apple.
- Separar estados de datos observados, calibración y clasificación experimental en las pantallas originales.
- Sustituir/controlar las rutas privadas de actualización que aún compiten con el puente.
- Actualización, cancelación, errores y pruebas de estabilidad/background.
- Automatizar el port previo desde entradas aportadas localmente, con hashes y comprobaciones por versión.

El repositorio no incorpora diagnósticos del dispositivo ni datos personales. Las declaraciones Swift son reconstrucciones parciales para llamadas observadas; no implementaciones Apple ni una API estable.
