# Readiness / Disposición para Series 11 — experimento

**Solo probado físicamente en Apple Watch Series 11 (Watch7,18), watchOS 27.3 (24S5284h). Última compilación local: 30, 15 de noviembre de 2026. Xcode 27.2 (27B52), SDK watchOS 27.2, puente arm64e. No se ha validado en otros relojes o versiones.**

English: Experimental original Cobalt UI bridge, tested only on Series 11 / Watch7,18 running watchOS 27.3 build 24S5284h. Not a general release. Requires your own compatible local Apple application and development signing. Sleep and Fitness cards are unfinished. The score is our own algorithm, not Apple's.

## Actualización de la compilación 30

El dial conserva el motor experimental anterior. En el reloj de prueba, HealthKit entregó duración y esfuerzo para los dos entrenamientos recientes. El subtítulo puede mostrar la carga registrada de siete días, calculada como suma de minutos por esfuerzo. La comparación histórica de Cobalt y los modelos completos de Sueño y Fitness siguen pendientes. Las lecturas nuevas de esfuerzo se solicitan por separado en Salud.

## Estado real

| Parte | Resultado verificado |
| --- | --- |
| Interfaz original Cobalt | El usuario confirmó el número en la app original, sin recrear su interfaz |
| Cálculo | Motor propio experimental `v3-experimental-nocturnal-mad`, usando datos públicos autorizados de HealthKit |
| Signos vitales nocturnos | Ocho noches traducidas a los modelos nativos; el usuario confirmó mediciones visibles |
| Puntuación de sueño | Tarjeta todavía incompleta; no se obtuvo el Sleep Score oficial de Apple |
| Fitness | Datos públicos de actividad disponibles; contribución/modelo de Fitness todavía pendientes |
| Referencia nocturna | Cuartiles propios; puede diferir de Signos Vitales de Apple. Última versión etiqueta «Referencia experimental»; texto visible aún sin confirmación del usuario |
| Segundo plano | Sin validación completa; no prometer actualizaciones continuas ni entregas garantizadas |
| Pruebas | 25 comprobaciones de regresión del motor/caché pasaron al preparar esta publicación |

El índice combina RMSSD nocturno derivado de series de latidos, pulso en reposo y duración del sueño. No es un cálculo clínicamente validado ni el algoritmo Apple. La normalización para el modelo nativo transforma 0…100 a −1…1 y usa los helpers de presentación nativos para la escala 0…10 y su categoría. No se añaden puntuaciones arbitrarias cuando faltan datos. No se presenta una noche histórica como la de hoy.

## Qué se publica

Código del motor y lector público, caché, traductores, captura del modelo original y proveedor, declaraciones ABI reconstruidas, herramientas de compilación/firma local y pruebas. Los cambios están separados de HermesEnabler: no cambian perfiles Ultra/Hermès ni carátulas.

**No incluye una `.app`/IPA lista para instalar, el ejecutable Cobalt, recursos o iconos Apple, firmware, frameworks de Apple ni SDK.** La prueba original depende de esos componentes y cada persona debe aportar su propia copia local compatible. El código de este repositorio por sí solo no reconstruye la aplicación propietaria. No se promete instalación universal ni soporte para cualquier firmware.

No se publican muestras de Salud, fotos personales, valores del perfil, UUID de muestras/dispositivos, registros del reloj, certificados o perfiles de aprovisionamiento.

## Compilar el puente

Desde esta carpeta, con Xcode completo seleccionado:

```sh
sh Tools/test.sh
zsh Tools/build-bridge.sh
```

El script descarga solamente el encabezado abierto `dyld-interposing.h` del proyecto dyld de Apple y verifica el hash usado en esta prueba. También acepta su ruta local como primer argumento. El overlay de HealthKit se genera a partir del SDK local; no redistribuye ese SDK. Salida: `.build/ReadinessBridge` (arm64e), sin instalar nada.

La UI privada, sus firmas Swift y direcciones del ejecutable son específicas de esta compilación. Una actualización puede romperlas. Las lecturas de Salud usan APIs públicas y autorización de solo lectura; la integración visual y el port usan componentes privados. No es compatible con una promesa de «solo APIs públicas» ni una distribución ordinaria por App Store.

## Preparar una app local compatible

La herramienta de exportación admite **únicamente** el paquete Cobalt-PublicHealth-Lab previamente portado de esta investigación, con ejecutable SHA-256:

```text
fad6c6b5a8c17cc52b910fb5a4e316af8316801ad55e3c21b67f58104cafcf22
```

Ese paquete de entrada NO se incluye. No confundirlo con el Cobalt original extraído del firmware: el port previo de arquitectura y las adaptaciones de carga no están automatizados por esta publicación. Si no tienes ese paquete exacto, puedes ejecutar las pruebas y compilar el puente, pero **esta publicación no ofrece todavía una instalación reproducible desde un firmware original**. La herramienta se detiene ante otro hash; no fuerces su aceptación.

```sh
python3 Tools/prepare-app.py /ruta/Cobalt-PublicHealth-Lab.app /ruta/local/Readiness.app
```

Asegúrate de que la app local carga `@executable_path/Frameworks/ReadinessBridge.framework/ReadinessBridge` (la entrada compatible ya contiene esa dependencia). Crea en tu cuenta de desarrollo el identificador `org.example.ReadinessBridge.watchkitapp` y un perfil de desarrollo para tu reloj con HealthKit público. Si cambias el identificador, cambia también la comprobación del bundle en `Bridge/PublicProfileBridge.m` antes de compilar. El archivo de entitlements debe corresponder a tu perfil e identificador, con `com.apple.developer.healthkit`, sin entitlements privados de Salud. Usa tu identidad y archivos locales:

```sh
python3 Tools/package-local.py /ruta/local/Readiness.app \
  --identity 'Apple Development: TU IDENTIDAD' \
  --profile /ruta/tu.mobileprovision \
  --entitlements /ruta/tus.entitlements
```

Esto firma localmente; no instala automáticamente. La app es watch-only. Usa Xcode o `xcrun devicectl device install app --device TU_DISPOSITIVO /ruta/local/Readiness.app` si decides probarla. No reemplaces una app existente sin conservar tu copia. La firma debe autorizar tu reloj; el paquete firmado del autor no permite a cualquiera instalarlo.

En el primer arranque concede solo las lecturas deseadas. Los requisitos iniciales incluyen fecha de nacimiento, estatura, peso y sueño. Si un registro existe en el iPhone pero es anterior a `earliestPermittedSampleDate()` del reloj, no será visible allí: ampliar permisos no elimina esa restricción. La prueba local resolvió el peso cuando el usuario añadió voluntariamente un registro reciente. La app no escribe ni modifica Salud.

## Limitaciones para colaborar

Las consultas privadas originales aún pueden ejecutarse y sobrescribir el estado; no están completamente sustituidas. La actualización automática, recuperación de errores, detalle de sueño y modelo Fitness necesitan trabajo. No se rellenan campos ausentes con ceros para aparentar compatibilidad. Al reportar problemas incluye modelo, watchOS/build, compilación del puente y mensaje visible; no adjuntes muestras ni registros personales sin revisarlos.

Consulta [Research/STATUS.md](Research/STATUS.md) para el recorrido y pendientes. La licencia del repositorio cubre nuestro código; no otorga derechos sobre el software, recursos o marcas Apple. Encabezado abierto de dyld: [fuente y licencia upstream](https://github.com/apple-oss-distributions/dyld/blob/main/include/mach-o/dyld-interposing.h).
