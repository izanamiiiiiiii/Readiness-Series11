"""Assemble and sign a LOCAL supplied app. No download or installation."""
from pathlib import Path
import argparse, plistlib, shutil, subprocess
p=argparse.ArgumentParser()
p.add_argument('app',type=Path)
p.add_argument('--identity',required=True)
p.add_argument('--profile',required=True,type=Path)
p.add_argument('--entitlements',required=True,type=Path)
a=p.parse_args(); root=Path(__file__).resolve().parent.parent
f=a.app/'Frameworks/ReadinessBridge.framework'
f.mkdir(parents=True,exist_ok=True)
shutil.copy2(root/'.build/ReadinessBridge',f/'ReadinessBridge')
if not (f/'Info.plist').exists():
 (f/'Info.plist').write_bytes(plistlib.dumps({'CFBundleExecutable':'ReadinessBridge','CFBundleIdentifier':'org.example.ReadinessBridge.framework','CFBundlePackageType':'FMWK','CFBundleVersion':'30'}))
i=a.app/'Info.plist'; info=plistlib.loads(i.read_bytes())
info.update(CFBundleIdentifier='org.example.ReadinessBridge.watchkitapp',CFBundleDisplayName='Readiness experimental',CFBundleVersion='30',NSHealthShareUsageDescription='Read existing sleep, heart and activity data for an experimental local readiness calculation.')
i.write_bytes(plistlib.dumps(info)); shutil.copy2(a.profile,a.app/'embedded.mobileprovision')
for command in [['codesign','--force','--sign',a.identity,str(f)],['codesign','--force','--sign',a.identity,'--entitlements',str(a.entitlements),'--generate-entitlement-der',str(a.app)],['codesign','--verify','--deep','--strict',str(a.app)]]:
 subprocess.run(command,check=True)
print('Signed local app:',a.app)
