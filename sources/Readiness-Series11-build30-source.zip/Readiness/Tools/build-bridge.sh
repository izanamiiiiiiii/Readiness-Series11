#!/bin/zsh
set -eu
root=${0:A:h:h}
cd "$root"
sdk=$(xcrun --sdk watchos --show-sdk-path)
build="$root/.build"
mkdir -p "$build/Modules" "$build/include" "$build/cache"
# Generate the SDK overlay locally. Apple's SDK is not redistributed here.
cat "$sdk/System/Library/Frameworks/HealthKit.framework/Modules/HealthKit.swiftmodule/arm64e-apple-watchos.swiftinterface" Tools/DayIndex.swiftinterface.fragment > "$build/Modules/HealthKit.swiftinterface"
if [[ -n ${1:-} ]]; then
 cp "$1" "$build/include/dyld-interposing.h"
else
 curl --fail --location 'https://raw.githubusercontent.com/apple-oss-distributions/dyld/main/include/mach-o/dyld-interposing.h' -o "$build/include/dyld-interposing.h"
fi
# Header version used by the verified build. Do not silently accept newer ABI changes.
python3 - "$build/include/dyld-interposing.h" <<'PY'
import hashlib,sys
assert hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest()=='763eeb269c19216b7963345567b9d20ca6591c73249571019a8763f8fcdc0e71', 'Header changed; review its ABI before building'
PY
for name in CombinedAllocationCapture ReferenceSubtitleInterpose; do
 xcrun clang -target arm64e-apple-watchos27.2 -isysroot "$sdk" -I "$build/include" -I Bridge -c "Bridge/$name.c" -o "$build/$name.o"
done
xcrun clang -target arm64e-apple-watchos27.2 -isysroot "$sdk" -fobjc-arc -c Bridge/PublicProfileBridge.m -o "$build/PublicProfileBridge.o"
xcrun swiftc -target arm64e-apple-watchos27.2 -sdk "$sdk" -swift-version 6 -parse-as-library -emit-library \
 -module-cache-path "$build/cache" -I "$build/Modules" -I Modules -I Bridge \
 Bridge/*.swift Engine/*.swift Translation/*.swift "$build/CombinedAllocationCapture.o" "$build/ReferenceSubtitleInterpose.o" "$build/PublicProfileBridge.o" \
 -framework HealthKit -Xlinker -undefined -Xlinker dynamic_lookup \
 -Xlinker -install_name -Xlinker @executable_path/Frameworks/ReadinessBridge.framework/ReadinessBridge \
 -o "$build/ReadinessBridge"
echo "Built $build/ReadinessBridge (arm64e). No app installed."
