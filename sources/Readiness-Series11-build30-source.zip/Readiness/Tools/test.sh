#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
swiftc -swift-version 6 -module-cache-path "$tmp/cache" "$root/Engine/RobustReadinessEngine.swift" "$root/Engine/NightQuality.swift" "$root/Engine/SafeRRAccumulator.swift" "$root/Engine/ReadinessStorageCoordinator.swift" "$root/Tests/Regression.swift" -o "$tmp/tests"
"$tmp/tests"
