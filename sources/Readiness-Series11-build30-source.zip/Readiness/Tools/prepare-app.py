"""Extend only a COPY's export trie; never patch text, PAC or field storage."""
from pathlib import Path
import struct,json,hashlib,shutil,re
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('source',type=Path)
parser.add_argument('output',type=Path)
args=parser.parse_args()
ROOT=Path(__file__).resolve().parent
SRC=args.source; DST=args.output
raw=(SRC/'Cobalt').read_bytes();original=bytes(raw);b=bytearray(raw)
assert hashlib.sha256(raw).hexdigest()=='fad6c6b5a8c17cc52b910fb5a4e316af8316801ad55e3c21b67f58104cafcf22', 'Unsupported input binary; stop before patching'
def digest(data):return hashlib.sha256(data).hexdigest()
cmds=[];segs=[];sections=[];q=32
for _ in range(struct.unpack_from('<I',b,16)[0]):
 c,z=struct.unpack_from('<II',b,q);cmds.append((c,q,z))
 if c==25:
  name=b[q+8:q+24].split(b'\0')[0].decode();a,vs,o,n=struct.unpack_from('<QQQQ',b,q+24);segs.append((name,a,vs,o,n,q))
  for j in range(struct.unpack_from('<I',b,q+64)[0]):
   s=q+72+80*j;sn=b[s:s+16].split(b'\0')[0].decode();a,n,o=struct.unpack_from('<QQI',b,s+32);sections.append((sn,a,n,o))
 q+=z
imagebase=next(s[1] for s in segs if s[0]=='__TEXT')
text=next(s for s in sections if s[0]=='__text')
exportcmd=next(((c,o) for c,o,z in cmds if c==0x80000033),None)
if exportcmd:exportoff,exportsize=struct.unpack_from('<II',b,exportcmd[1]+8)
else:
 exportcmd=next((c,o) for c,o,z in cmds if c in [0x22,0x80000022]);exportoff,exportsize=struct.unpack_from('<II',b,exportcmd[1]+40)
def ul(data,pos):
 v=sh=0
 while True:
  k=data[pos];pos+=1;v|=(k&127)<<sh
  if k<128:return v,pos
  sh+=7
def enc(v):
 out=bytearray()
 while True:
  k=v&127;v>>=7;out.append(k|(128 if v else 0))
  if not v:return bytes(out)
exports={};trie=bytes(b[exportoff:exportoff+exportsize])
def walk(pos,name):
 size,p=ul(trie,pos);end=p+size
 if size:
  flags,t=ul(trie,p)
  assert not flags&0x18, 'Reexports/resolvers need their own preservation logic'
  address,t=ul(trie,t);exports[name]=(flags,address)
 children=trie[end];p=end+1
 for _ in range(children):
  z=trie.index(0,p);edge=trie[p:z].decode();child,p=ul(trie,z+1);walk(child,name+edge)
walk(0,'')
assert set(exports)=={'_main','__mh_execute_header'},'Unexpected source exports: stop for review'
rows=json.loads((ROOT/'cobalt-export-aliases.json').read_text())
for row in rows:
 exports[row['symbol']]=(0,int(row['address'],16)-imagebase)
# Simple deterministic trie, one edge per whole name. ULEB offsets converge monotonically.
names=sorted(exports);nodes=[]
for name in names:
 flags,address=exports[name];terminal=enc(flags)+enc(address);nodes.append(enc(len(terminal))+terminal+b'\0')
offsets=[0]*len(names)
for _ in range(20):
 root=b'\0'+bytes([len(names)])+b''.join(n.encode()+b'\0'+enc(o) for n,o in zip(names,offsets))
 cursor=len(root);updated=[]
 for node in nodes:updated.append(cursor);cursor+=len(node)
 if updated==offsets:break
 offsets=updated
else:raise RuntimeError('Trie did not converge')
newtrie=root+b''.join(nodes)
sig=next((item for item in cmds if item[0]==0x1d),None)
if not sig:raise RuntimeError('Expected input code-signature command missing')
sigoff,sigsize=struct.unpack_from('<II',b,sig[1]+8)
assert len(newtrie)<=sigsize,'New export trie will not fit in old signature space'
newOffset=sigoff
b=b[:sigoff]+bytearray(newtrie)
if exportcmd[0]==0x80000033:struct.pack_into('<II',b,exportcmd[1]+8,newOffset,len(newtrie))
else:struct.pack_into('<II',b,exportcmd[1]+40,newOffset,len(newtrie))
link=next(s for s in segs if s[0]=='__LINKEDIT');newSize=len(b)-link[3]
struct.pack_into('<Q',b,link[5]+48,newSize);struct.pack_into('<Q',b,link[5]+32,(newSize+0x3fff)&~0x3fff)
oldSize=struct.unpack_from('<I',b,20)[0]
commands=b''.join(bytes(b[o:o+z]) for c,o,z in cmds if c!=0x1d)
b[32:32+oldSize]=commands+bytes(oldSize-len(commands))
struct.pack_into('<II',b,16,len(cmds)-1,len(commands))
assert b[text[3]:text[3]+text[2]]==original[text[3]:text[3]+text[2]],'Text changed unexpectedly'
assert b[8:12]==original[8:12],'Architecture/PAC mode changed'
if DST.exists():raise FileExistsError(DST)
shutil.copytree(SRC,DST);(DST/'Cobalt').write_bytes(b)
print('Prepared unsigned local app:',DST)
